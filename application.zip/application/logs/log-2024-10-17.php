<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-17 06:27:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-17 06:27:08 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-17 06:32:00 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-17 07:22:21 --> 404 Page Not Found: Admin/manage_resumes
ERROR - 2024-10-17 07:22:26 --> 404 Page Not Found: Manage_resumes/index
ERROR - 2024-10-17 07:22:31 --> 404 Page Not Found: Manage_resumesphp/index
ERROR - 2024-10-17 07:22:50 --> 404 Page Not Found: Resume/manage_resumes
ERROR - 2024-10-17 07:42:25 --> 404 Page Not Found: ResumeController/save_resume
ERROR - 2024-10-17 07:42:28 --> 404 Page Not Found: ResumeController/save_resume
ERROR - 2024-10-17 08:05:39 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 08:05:44 --> 404 Page Not Found: Resume/index
ERROR - 2024-10-17 08:06:10 --> 404 Page Not Found: Resume/manage_resumes
ERROR - 2024-10-17 08:06:14 --> 404 Page Not Found: Resume/index
ERROR - 2024-10-17 08:11:27 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\resume.php 108
ERROR - 2024-10-17 08:11:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\resume.php 108
ERROR - 2024-10-17 08:12:06 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\resume.php 108
ERROR - 2024-10-17 08:12:06 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\resume.php 108
ERROR - 2024-10-17 08:13:01 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\resume.php 108
ERROR - 2024-10-17 08:13:01 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\resume.php 108
ERROR - 2024-10-17 08:17:25 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\manage_resumes.php 65
ERROR - 2024-10-17 08:17:25 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\manage_resumes.php 66
ERROR - 2024-10-17 08:17:25 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\manage_resumes.php 65
ERROR - 2024-10-17 08:17:25 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\manage_resumes.php 66
ERROR - 2024-10-17 08:19:18 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\resume.php 55
ERROR - 2024-10-17 08:19:18 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\resume.php 55
ERROR - 2024-10-17 08:20:02 --> 404 Page Not Found: Admin/resume
ERROR - 2024-10-17 08:20:07 --> 404 Page Not Found: Resume/manage_resumes
ERROR - 2024-10-17 08:20:12 --> 404 Page Not Found: Resumes/manage_resumes
ERROR - 2024-10-17 08:20:19 --> 404 Page Not Found: Resume/manage_resumes
ERROR - 2024-10-17 08:35:12 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 79
ERROR - 2024-10-17 08:35:12 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 80
ERROR - 2024-10-17 08:35:12 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\resume.php 81
ERROR - 2024-10-17 08:35:12 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 79
ERROR - 2024-10-17 08:35:12 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 80
ERROR - 2024-10-17 08:35:12 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\resume.php 81
ERROR - 2024-10-17 08:35:12 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 79
ERROR - 2024-10-17 08:35:12 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 80
ERROR - 2024-10-17 08:35:12 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\resume.php 81
ERROR - 2024-10-17 08:35:31 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 80
ERROR - 2024-10-17 08:35:31 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\resume.php 81
ERROR - 2024-10-17 08:35:31 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 80
ERROR - 2024-10-17 08:35:31 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\resume.php 81
ERROR - 2024-10-17 08:35:31 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 80
ERROR - 2024-10-17 08:35:31 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\resume.php 81
ERROR - 2024-10-17 08:35:48 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\resume.php 81
ERROR - 2024-10-17 08:35:48 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\resume.php 81
ERROR - 2024-10-17 08:35:48 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\resume.php 81
ERROR - 2024-10-17 08:42:38 --> Severity: error --> Exception: syntax error, unexpected token ")", expecting ";" C:\xampp\htdocs\portfolio\application\views\admin\resume.php 80
ERROR - 2024-10-17 08:43:28 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\portfolio\application\views\admin\resume.php 80
ERROR - 2024-10-17 08:44:43 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 08:45:21 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\manage_resumes.php 65
ERROR - 2024-10-17 08:45:21 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\manage_resumes.php 66
ERROR - 2024-10-17 08:45:21 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\manage_resumes.php 65
ERROR - 2024-10-17 08:45:21 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\manage_resumes.php 66
ERROR - 2024-10-17 08:45:21 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\manage_resumes.php 65
ERROR - 2024-10-17 08:45:21 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\manage_resumes.php 66
ERROR - 2024-10-17 09:03:18 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 10:52:05 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\ResumeController.php 115
ERROR - 2024-10-17 10:52:34 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting "function" or "const" C:\xampp\htdocs\portfolio\application\controllers\ResumeController.php 133
ERROR - 2024-10-17 10:52:36 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting "function" or "const" C:\xampp\htdocs\portfolio\application\controllers\ResumeController.php 133
ERROR - 2024-10-17 10:56:54 --> 404 Page Not Found: Resume/update_resume
ERROR - 2024-10-17 10:57:42 --> 404 Page Not Found: Resume/update_resume
ERROR - 2024-10-17 10:58:07 --> 404 Page Not Found: Resume/update_resume
ERROR - 2024-10-17 10:58:11 --> 404 Page Not Found: Resume/update_resume
ERROR - 2024-10-17 10:58:37 --> 404 Page Not Found: Resume/update_resume
ERROR - 2024-10-17 10:59:02 --> Severity: error --> Exception: Call to undefined method Resume_model::add_resues() C:\xampp\htdocs\portfolio\application\controllers\ResumeController.php 127
ERROR - 2024-10-17 11:00:50 --> Severity: error --> Exception: Call to undefined method Resume_model::add_resues() C:\xampp\htdocs\portfolio\application\controllers\ResumeController.php 127
ERROR - 2024-10-17 11:00:51 --> Severity: error --> Exception: Call to undefined method Resume_model::add_resues() C:\xampp\htdocs\portfolio\application\controllers\ResumeController.php 127
ERROR - 2024-10-17 12:17:50 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 12:18:05 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 12:51:51 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 23
ERROR - 2024-10-17 12:51:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 23
ERROR - 2024-10-17 12:52:22 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 32
ERROR - 2024-10-17 12:52:22 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 38
ERROR - 2024-10-17 12:52:22 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 32
ERROR - 2024-10-17 12:52:22 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 38
ERROR - 2024-10-17 12:54:33 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 32
ERROR - 2024-10-17 12:54:33 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 38
ERROR - 2024-10-17 12:54:33 --> Severity: Warning --> Undefined property: stdClass::$title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 32
ERROR - 2024-10-17 12:54:33 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\resume.php 38
ERROR - 2024-10-17 12:57:06 --> Severity: error --> Exception: Call to undefined method Resume_model::get_hresumes() C:\xampp\htdocs\portfolio\application\controllers\ResumeController.php 19
ERROR - 2024-10-17 12:58:19 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\resume.php 77
ERROR - 2024-10-17 12:58:19 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\resume.php 83
ERROR - 2024-10-17 12:58:19 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\resume.php 89
ERROR - 2024-10-17 12:59:37 --> Severity: error --> Exception: Call to undefined method Resume_model::get_hresumes() C:\xampp\htdocs\portfolio\application\controllers\ResumeController.php 19
ERROR - 2024-10-17 13:00:15 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\resume.php 77
ERROR - 2024-10-17 13:00:15 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\resume.php 83
ERROR - 2024-10-17 13:00:15 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\resume.php 89
ERROR - 2024-10-17 13:07:41 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:07:48 --> 404 Page Not Found: Resume/manage_resume1
ERROR - 2024-10-17 13:08:03 --> Query error: Unknown column 'year' in 'field list' - Invalid query: UPDATE `hresumes` SET `year` = '2024', `work` = 'Developer', `u_name` = 'xlligent Softwares', `description` = 'i am adeveloper'
WHERE `id` = '1'
ERROR - 2024-10-17 13:08:43 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:09:25 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\resume.php 77
ERROR - 2024-10-17 13:09:25 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\resume.php 83
ERROR - 2024-10-17 13:09:25 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\resume.php 89
ERROR - 2024-10-17 13:13:18 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\resume.php 69
ERROR - 2024-10-17 13:13:18 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\resume.php 76
ERROR - 2024-10-17 13:13:18 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\resume.php 83
ERROR - 2024-10-17 13:14:30 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\resume.php 69
ERROR - 2024-10-17 13:14:30 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\resume.php 76
ERROR - 2024-10-17 13:14:30 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\resume.php 83
ERROR - 2024-10-17 13:15:44 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\resume.php 69
ERROR - 2024-10-17 13:15:44 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\resume.php 76
ERROR - 2024-10-17 13:15:44 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\resume.php 83
ERROR - 2024-10-17 13:16:40 --> 404 Page Not Found: Resume/manage_resumes
ERROR - 2024-10-17 13:17:25 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:17:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:17:57 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:17:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:18:20 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:18:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:19:26 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:19:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:19:41 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\resume.php 69
ERROR - 2024-10-17 13:19:41 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\resume.php 76
ERROR - 2024-10-17 13:19:41 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\resume.php 83
ERROR - 2024-10-17 13:20:00 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:20:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:21:16 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:21:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:21:39 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:21:46 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:21:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:21:51 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:22:14 --> Query error: Unknown column 'year' in 'field list' - Invalid query: UPDATE `hresumes` SET `year` = '2024', `work` = 'Developer', `u_name` = 'Xlligent', `description` = 'xllgent'
WHERE `id` = '4'
ERROR - 2024-10-17 13:22:28 --> Query error: Unknown column 'year' in 'field list' - Invalid query: UPDATE `hresumes` SET `year` = '2024', `work` = 'Developer', `u_name` = 'Xlligent', `description` = 'xllgent'
WHERE `id` = '4'
ERROR - 2024-10-17 13:22:40 --> Query error: Unknown column 'year' in 'field list' - Invalid query: UPDATE `hresumes` SET `year` = '2024', `work` = 'Developer', `u_name` = 'Xlligent', `description` = 'xllgent'
WHERE `id` = '4'
ERROR - 2024-10-17 13:24:52 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:25:07 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:25:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:27:16 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:27:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:27:18 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:27:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:27:22 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:27:37 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:27:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:31:26 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:31:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:31:33 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:31:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:31:36 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:31:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:32:27 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:32:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:33:25 --> Query error: Column 'year' cannot be null - Invalid query: INSERT INTO `resumes` (`year`, `work`, `u_name`, `description`) VALUES (NULL, NULL, 'Xlligent', 'iiii                                                ')
ERROR - 2024-10-17 13:33:49 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:33:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:33:54 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:33:54 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:34:12 --> Query error: Column 'year' cannot be null - Invalid query: INSERT INTO `resumes` (`year`, `work`, `u_name`, `description`) VALUES (NULL, NULL, 'Xlligent', 'sssss')
ERROR - 2024-10-17 13:35:14 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:35:14 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:35:17 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:35:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:35:36 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:35:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:35:47 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:39:55 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:42:51 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:43:07 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:43:07 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:43:16 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:43:33 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:43:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:43:42 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:46:00 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:46:01 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:46:06 --> 404 Page Not Found: ResumeController/manage_resume
ERROR - 2024-10-17 13:46:07 --> 404 Page Not Found: ResumeController/manage_resume
ERROR - 2024-10-17 13:46:22 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:48:56 --> 404 Page Not Found: Resume/manage_resumes
ERROR - 2024-10-17 13:50:39 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:50:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:51:20 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\resume.php 69
ERROR - 2024-10-17 13:51:20 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\resume.php 76
ERROR - 2024-10-17 13:51:20 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\resume.php 83
ERROR - 2024-10-17 13:51:49 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:51:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:51:54 --> 404 Page Not Found: Resume/manage_resume
ERROR - 2024-10-17 13:53:21 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:53:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:53:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 13:53:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 13:53:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 13:55:24 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:55:24 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:55:37 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:55:37 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:55:57 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:55:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:59:35 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 13:59:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:01:41 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:01:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:02:29 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:02:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:02:59 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:02:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:03:30 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:03:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:04:01 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:04:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\resume.php 22
ERROR - 2024-10-17 14:09:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 14:09:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 14:09:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 14:21:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 14:21:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 14:21:03 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 14:28:27 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 14:28:27 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 14:28:27 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-17 14:30:59 --> 404 Page Not Found: Resume/index
ERROR - 2024-10-17 14:35:33 --> 404 Page Not Found: Admin/calendar
ERROR - 2024-10-17 14:41:31 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\resume.php 65
ERROR - 2024-10-17 14:41:31 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\resume.php 71
ERROR - 2024-10-17 14:41:31 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\resume.php 77
ERROR - 2024-10-17 14:47:03 --> 404 Page Not Found: Resume/manage_resumes
ERROR - 2024-10-17 14:47:58 --> 404 Page Not Found: Resume/manage_resumes

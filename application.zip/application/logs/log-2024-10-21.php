<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-21 06:28:23 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-21 06:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-21 06:41:53 --> 404 Page Not Found: Admin/login.html
ERROR - 2024-10-21 06:44:32 --> 404 Page Not Found: Admin/login.html
ERROR - 2024-10-21 06:45:23 --> 404 Page Not Found: Admin/login.html
ERROR - 2024-10-21 06:48:46 --> 404 Page Not Found: Admin/login.html
ERROR - 2024-10-21 06:49:44 --> 404 Page Not Found: Admin/login.html
ERROR - 2024-10-21 06:49:53 --> 404 Page Not Found: SskillController/sskill
ERROR - 2024-10-21 06:51:11 --> 404 Page Not Found: SskillController/sskill
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 121
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 121
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 121
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 121
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 121
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 121
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 123
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 126
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 133
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 135
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 140
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Undefined variable $skill C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:07:27 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 153
ERROR - 2024-10-21 07:13:31 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:13:31 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:13:31 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:13:31 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:13:31 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:13:31 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:14:12 --> Severity: Warning --> Undefined property: SskillController::$SskillModel C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 42
ERROR - 2024-10-21 07:14:12 --> Severity: error --> Exception: Call to a member function insert_sskill() on null C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 42
ERROR - 2024-10-21 07:15:18 --> 404 Page Not Found: Sskill/index
ERROR - 2024-10-21 07:15:20 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:20 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:20 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:20 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:20 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:20 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:23 --> Severity: Warning --> Undefined property: SskillController::$SskillModel C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 42
ERROR - 2024-10-21 07:15:23 --> Severity: error --> Exception: Call to a member function insert_sskill() on null C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 42
ERROR - 2024-10-21 07:15:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:27 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:29 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:29 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:29 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:29 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:29 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:29 --> Severity: Warning --> Undefined property: stdClass::$subtitle C:\xampp\htdocs\portfolio\application\views\admin\sskill.php 65
ERROR - 2024-10-21 07:15:41 --> Severity: Warning --> Undefined property: SskillController::$SskillModel C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 42
ERROR - 2024-10-21 07:15:41 --> Severity: error --> Exception: Call to a member function insert_sskill() on null C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 42
ERROR - 2024-10-21 07:16:52 --> Severity: Warning --> Undefined property: SskillController::$Skill_model C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 19
ERROR - 2024-10-21 07:16:52 --> Severity: error --> Exception: Call to a member function get_skills() on null C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 19
ERROR - 2024-10-21 07:16:56 --> Severity: Warning --> Undefined property: SskillController::$Skill_model C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 19
ERROR - 2024-10-21 07:16:56 --> Severity: error --> Exception: Call to a member function get_skills() on null C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 19
ERROR - 2024-10-21 07:17:32 --> Severity: error --> Exception: Call to undefined method SskillModel::get_skills() C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 19
ERROR - 2024-10-21 07:18:03 --> Severity: error --> Exception: Call to undefined method SskillModel::get_sskills() C:\xampp\htdocs\portfolio\application\controllers\SskillController.php 19
ERROR - 2024-10-21 07:18:32 --> Severity: error --> Exception: Too few arguments to function SskillModel::get_sskill(), 0 passed in C:\xampp\htdocs\portfolio\application\controllers\SskillController.php on line 19 and exactly 1 expected C:\xampp\htdocs\portfolio\application\models\SskillModel.php 22
ERROR - 2024-10-21 07:20:54 --> 404 Page Not Found: Sskill/index
ERROR - 2024-10-21 07:23:24 --> 404 Page Not Found: Sskill/index
ERROR - 2024-10-21 07:23:34 --> 404 Page Not Found: Asmin/sskill
ERROR - 2024-10-21 07:24:02 --> 404 Page Not Found: Sskill/index
ERROR - 2024-10-21 07:24:11 --> 404 Page Not Found: Adminsskill/index
ERROR - 2024-10-21 07:24:35 --> 404 Page Not Found: Admin/sskill
ERROR - 2024-10-21 08:42:16 --> 404 Page Not Found: Admin/contact
ERROR - 2024-10-21 09:15:40 --> 404 Page Not Found: Admin/contact
ERROR - 2024-10-21 10:42:51 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-21 10:42:51 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-21 10:42:51 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-21 10:43:43 --> 404 Page Not Found: Admin/contact

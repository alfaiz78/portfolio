<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-18 06:18:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 06:24:21 --> Severity: error --> Exception: syntax error, unexpected token "-", expecting "function" or "const" C:\xampp\htdocs\portfolio\application\controllers\ResumeController.php 64
ERROR - 2024-10-18 06:30:40 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:30:40 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:30:40 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:32:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:32:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:32:12 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:34:21 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:34:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:34:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:47:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:47:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:47:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:49:00 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:49:00 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 06:49:00 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 07:03:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 07:03:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 07:03:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 07:03:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 07:03:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 07:03:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 89
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 89
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 93
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 93
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 95
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 95
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 101
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 101
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 89
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 89
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 93
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 93
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 95
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 95
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 101
ERROR - 2024-10-18 07:19:40 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 101
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 89
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 89
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 93
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 93
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 95
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 95
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 101
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 101
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 89
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 89
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 93
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 93
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 95
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 95
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Undefined variable $resume C:\xampp\htdocs\portfolio\application\views\admin\slider.php 101
ERROR - 2024-10-18 07:20:23 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 101
ERROR - 2024-10-18 07:28:04 --> 404 Page Not Found: AdminSLIDER/index
ERROR - 2024-10-18 07:29:10 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-18 07:30:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 07:30:55 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 07:30:55 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 07:30:55 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-18 07:47:03 --> Severity: Warning --> Undefined variable $THIS C:\xampp\htdocs\portfolio\application\controllers\MyController.php 35
ERROR - 2024-10-18 07:47:03 --> Severity: Warning --> Attempt to read property "load" on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 35
ERROR - 2024-10-18 07:47:03 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 35
ERROR - 2024-10-18 07:47:33 --> Severity: Warning --> Undefined variable $THIS C:\xampp\htdocs\portfolio\application\controllers\MyController.php 35
ERROR - 2024-10-18 07:47:33 --> Severity: Warning --> Attempt to read property "load" on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 35
ERROR - 2024-10-18 07:47:33 --> Severity: error --> Exception: Call to a member function model() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 35
ERROR - 2024-10-18 07:48:56 --> Severity: error --> Exception: Undefined constant "hresumes" C:\xampp\htdocs\portfolio\application\controllers\MyController.php 51
ERROR - 2024-10-18 07:49:29 --> Severity: Warning --> Undefined property: Mycontroller::$resume_model_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 51
ERROR - 2024-10-18 07:49:29 --> Severity: error --> Exception: Call to a member function get_hresumes() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 51
ERROR - 2024-10-18 08:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 08:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 08:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 08:10:31 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-18 08:18:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 08:18:42 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-18 08:18:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 08:18:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 08:42:08 --> 404 Page Not Found: ResumeController/resume
ERROR - 2024-10-18 08:42:46 --> 404 Page Not Found: ResumeController/resume
ERROR - 2024-10-18 08:43:01 --> 404 Page Not Found: ResumeController/resume
ERROR - 2024-10-18 08:43:51 --> 404 Page Not Found: ResumeController/resume
ERROR - 2024-10-18 08:53:51 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 08:53:58 --> 404 Page Not Found: Admin/services
ERROR - 2024-10-18 08:54:58 --> 404 Page Not Found: Admin/services
ERROR - 2024-10-18 08:55:00 --> 404 Page Not Found: Admin/services
ERROR - 2024-10-18 08:55:12 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 08:59:45 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 08:59:48 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 09:00:05 --> Severity: error --> Exception: Call to undefined method Service_model::get_hservices() C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 18
ERROR - 2024-10-18 09:00:09 --> Severity: error --> Exception: Call to undefined method Service_model::get_hservices() C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 18
ERROR - 2024-10-18 09:05:38 --> Severity: error --> Exception: Call to undefined method Service_model::get_hservices() C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 18
ERROR - 2024-10-18 09:05:52 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 22
ERROR - 2024-10-18 09:06:22 --> Severity: error --> Exception: Call to undefined method Service_model::get_hservices() C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 18
ERROR - 2024-10-18 09:08:02 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\service.php 81
ERROR - 2024-10-18 09:08:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\service.php 81
ERROR - 2024-10-18 09:08:51 --> Severity: error --> Exception: Call to undefined method Service_model::get_hservices() C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 18
ERROR - 2024-10-18 09:09:57 --> Severity: Warning --> Undefined variable $hresumes C:\xampp\htdocs\portfolio\application\views\admin\service.php 81
ERROR - 2024-10-18 09:09:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\service.php 81
ERROR - 2024-10-18 09:20:41 --> Query error: Table 'portfolio.hservices' doesn't exist - Invalid query: SELECT *
FROM `hservices`
ERROR - 2024-10-18 09:20:46 --> Query error: Table 'portfolio.hservices' doesn't exist - Invalid query: SELECT *
FROM `hservices`
ERROR - 2024-10-18 10:38:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 10:38:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 10:38:19 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-18 10:38:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 10:39:03 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\service.php 128
ERROR - 2024-10-18 10:39:03 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\service.php 129
ERROR - 2024-10-18 10:39:03 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\service.php 130
ERROR - 2024-10-18 10:50:14 --> 404 Page Not Found: Service/manage_service
ERROR - 2024-10-18 10:51:15 --> 404 Page Not Found: Service/manage_service
ERROR - 2024-10-18 10:51:18 --> Severity: Warning --> Undefined property: stdClass::$year C:\xampp\htdocs\portfolio\application\views\admin\manage_service.php 28
ERROR - 2024-10-18 10:51:18 --> Severity: Warning --> Undefined property: stdClass::$work C:\xampp\htdocs\portfolio\application\views\admin\manage_service.php 34
ERROR - 2024-10-18 10:51:18 --> Severity: Warning --> Undefined property: stdClass::$u_name C:\xampp\htdocs\portfolio\application\views\admin\manage_service.php 40
ERROR - 2024-10-18 10:52:25 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 10:53:12 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 10:53:36 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 10:54:56 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 10:57:00 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 10:57:51 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 10:57:54 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 10:57:56 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 10:59:44 --> Severity: error --> Exception: syntax error, unexpected token "echo" C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 94
ERROR - 2024-10-18 11:00:14 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:01:07 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:01:26 --> 404 Page Not Found: Admin/save_service
ERROR - 2024-10-18 11:01:39 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:06:19 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:06:23 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:06:34 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:07:21 --> 404 Page Not Found: ServiceController/update_service
ERROR - 2024-10-18 11:07:42 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:10:33 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:10:35 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:10:35 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:10:35 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:10:36 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:10:36 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:10:36 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:10:37 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:10:37 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:10:46 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:11:46 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:14:35 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:14:45 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:14:51 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:15:50 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:19:32 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:19:41 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:20:30 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:21:27 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:23:17 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:23:56 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:24:44 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:24:53 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:25:15 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:27:25 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:27:36 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:27:39 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:28:14 --> 404 Page Not Found: ServiceController/delete_service
ERROR - 2024-10-18 11:28:41 --> 404 Page Not Found: ServiceController/delete_service
ERROR - 2024-10-18 11:29:29 --> 404 Page Not Found: ServiceController/delete_service
ERROR - 2024-10-18 11:29:55 --> 404 Page Not Found: ServiceController/delete_service
ERROR - 2024-10-18 11:31:59 --> 404 Page Not Found: Service/index
ERROR - 2024-10-18 11:32:05 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 143
ERROR - 2024-10-18 11:32:07 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 143
ERROR - 2024-10-18 11:32:08 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 143
ERROR - 2024-10-18 11:32:14 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\ServiceController.php 143
ERROR - 2024-10-18 11:33:19 --> 404 Page Not Found: ServiceController/add_service
ERROR - 2024-10-18 11:34:12 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:36:12 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:41:40 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:41:59 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:42:07 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:42:12 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:42:18 --> 404 Page Not Found: Service/save_services
ERROR - 2024-10-18 11:42:22 --> 404 Page Not Found: Save_services/2
ERROR - 2024-10-18 11:42:25 --> 404 Page Not Found: 2/index
ERROR - 2024-10-18 11:43:16 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:46:58 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:47:09 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:47:15 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 11:47:35 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:51:37 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 11:51:40 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 11:51:59 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 11:52:04 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 11:52:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 11:52:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 11:52:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 11:52:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 11:52:46 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 11:54:44 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:01:12 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 12:01:33 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:03:27 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:04:04 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:04:17 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:05:58 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:07:20 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:08:23 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:08:30 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:09:15 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:09:20 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:09:58 --> 404 Page Not Found: Admin/service
ERROR - 2024-10-18 12:16:06 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\portfolio\application\views\index.php 648
ERROR - 2024-10-18 12:22:44 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\xampp\htdocs\portfolio\application\views\index.php 209
ERROR - 2024-10-18 12:26:03 --> Severity: error --> Exception: Call to undefined method Resume_model::get_hservices() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:26:49 --> Severity: Warning --> Undefined property: Mycontroller::$Service_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:26:49 --> Severity: error --> Exception: Call to a member function get_hservices() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:29:12 --> Severity: Warning --> Undefined property: Mycontroller::$Service_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:29:12 --> Severity: error --> Exception: Call to a member function get_hservices() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:29:14 --> Severity: Warning --> Undefined property: Mycontroller::$Service_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:29:14 --> Severity: error --> Exception: Call to a member function get_hservices() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:29:15 --> Severity: Warning --> Undefined property: Mycontroller::$Service_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:29:15 --> Severity: error --> Exception: Call to a member function get_hservices() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:29:15 --> Severity: Warning --> Undefined property: Mycontroller::$Service_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:29:15 --> Severity: error --> Exception: Call to a member function get_hservices() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 52
ERROR - 2024-10-18 12:29:28 --> Severity: Warning --> Undefined property: Mycontroller::$Service_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 53
ERROR - 2024-10-18 12:29:28 --> Severity: error --> Exception: Call to a member function get_services() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 53
ERROR - 2024-10-18 12:29:29 --> Severity: Warning --> Undefined property: Mycontroller::$Service_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 53
ERROR - 2024-10-18 12:29:29 --> Severity: error --> Exception: Call to a member function get_services() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 53
ERROR - 2024-10-18 12:29:30 --> Severity: Warning --> Undefined property: Mycontroller::$Service_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 53
ERROR - 2024-10-18 12:29:30 --> Severity: error --> Exception: Call to a member function get_services() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 53
ERROR - 2024-10-18 12:29:30 --> Severity: Warning --> Undefined property: Mycontroller::$Service_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 53
ERROR - 2024-10-18 12:29:30 --> Severity: error --> Exception: Call to a member function get_services() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 53
ERROR - 2024-10-18 12:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 12:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 12:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 12:31:13 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-18 12:39:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 12:39:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 12:39:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 12:39:42 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-18 12:44:24 --> Severity: Warning --> Undefined property: stdClass::$icon C:\xampp\htdocs\portfolio\application\views\index.php 223
ERROR - 2024-10-18 12:44:24 --> Severity: Warning --> Undefined property: stdClass::$icon C:\xampp\htdocs\portfolio\application\views\index.php 223
ERROR - 2024-10-18 12:44:24 --> Severity: Warning --> Undefined property: stdClass::$icon C:\xampp\htdocs\portfolio\application\views\index.php 223
ERROR - 2024-10-18 12:56:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 12:56:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 12:56:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 12:56:42 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-18 13:08:37 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 13:08:40 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 13:08:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 13:08:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 13:08:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 13:08:56 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 13:09:26 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 13:09:29 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 13:12:29 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 13:12:29 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 13:12:29 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-18 20:18:22 --> 404 Page Not Found: Images/image_1.jpg
ERROR - 2024-10-18 20:18:22 --> 404 Page Not Found: Images/image_2.jpg
ERROR - 2024-10-18 20:18:22 --> 404 Page Not Found: Images/image_3.jpg
ERROR - 2024-10-18 20:18:32 --> 404 Page Not Found: Singlehtml/index
ERROR - 2024-10-18 20:20:04 --> 404 Page Not Found: Images/image_3.jpg
ERROR - 2024-10-18 20:20:04 --> 404 Page Not Found: Images/image_2.jpg
ERROR - 2024-10-18 20:42:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 20:42:21 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-18 20:43:19 --> 404 Page Not Found: Admin/profile
ERROR - 2024-10-18 21:17:09 --> Query error: Table 'portfolio.hskills' doesn't exist - Invalid query: SELECT *
FROM `hskills`
ERROR - 2024-10-18 21:21:00 --> Severity: Warning --> Undefined variable $hservices C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-18 21:21:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23

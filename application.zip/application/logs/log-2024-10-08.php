<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-08 00:21:21 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 181
ERROR - 2024-10-08 00:21:23 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 181
ERROR - 2024-10-08 00:21:25 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 181
ERROR - 2024-10-08 00:21:29 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 181
ERROR - 2024-10-08 00:21:30 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 181
ERROR - 2024-10-08 00:21:34 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 181
ERROR - 2024-10-08 00:21:37 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 181
ERROR - 2024-10-08 00:21:41 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 181
ERROR - 2024-10-08 00:21:41 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 181
ERROR - 2024-10-08 00:21:54 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 181
ERROR - 2024-10-08 00:23:42 --> Query error: Table 'portfolio.sliders' doesn't exist - Invalid query: SELECT *
FROM `sliders`
ERROR - 2024-10-08 00:23:44 --> Query error: Table 'portfolio.sliders' doesn't exist - Invalid query: SELECT *
FROM `sliders`
ERROR - 2024-10-08 00:23:57 --> Query error: Table 'portfolio.sliders' doesn't exist - Invalid query: SELECT *
FROM `sliders`
ERROR - 2024-10-08 00:23:58 --> Query error: Table 'portfolio.sliders' doesn't exist - Invalid query: SELECT *
FROM `sliders`
ERROR - 2024-10-08 00:23:59 --> Query error: Table 'portfolio.sliders' doesn't exist - Invalid query: SELECT *
FROM `sliders`
ERROR - 2024-10-08 00:23:59 --> Query error: Table 'portfolio.sliders' doesn't exist - Invalid query: SELECT *
FROM `sliders`
ERROR - 2024-10-08 00:30:52 --> 404 Page Not Found: Login/slider
ERROR - 2024-10-08 00:30:53 --> 404 Page Not Found: Login/slider
ERROR - 2024-10-08 00:30:54 --> 404 Page Not Found: Login/slider
ERROR - 2024-10-08 00:30:55 --> 404 Page Not Found: Login/slider
ERROR - 2024-10-08 00:30:56 --> 404 Page Not Found: Login/slider
ERROR - 2024-10-08 00:38:05 --> 404 Page Not Found: Slider/index
ERROR - 2024-10-08 00:39:56 --> 404 Page Not Found: Admin/slider
ERROR - 2024-10-08 06:40:00 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 06:40:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 06:40:10 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 07:31:03 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 225
ERROR - 2024-10-08 07:32:18 --> Severity: Warning --> Undefined property: Mycontroller::$admin C:\xampp\htdocs\portfolio\application\controllers\MyController.php 145
ERROR - 2024-10-08 07:32:18 --> Severity: error --> Exception: Call to undefined function slider() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 145
ERROR - 2024-10-08 07:32:47 --> Severity: Warning --> Undefined property: Mycontroller::$admin C:\xampp\htdocs\portfolio\application\controllers\MyController.php 145
ERROR - 2024-10-08 07:32:47 --> Severity: error --> Exception: Call to undefined function slider() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 145
ERROR - 2024-10-08 07:33:18 --> 404 Page Not Found: Slider/index
ERROR - 2024-10-08 07:52:25 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 211
ERROR - 2024-10-08 07:52:27 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 211
ERROR - 2024-10-08 07:54:05 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 211
ERROR - 2024-10-08 07:54:43 --> Severity: Warning --> Undefined variable $slider C:\xampp\htdocs\portfolio\application\views\admin\slider.php 8
ERROR - 2024-10-08 07:54:43 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 8
ERROR - 2024-10-08 07:54:43 --> Severity: Warning --> Undefined variable $slider C:\xampp\htdocs\portfolio\application\views\admin\slider.php 12
ERROR - 2024-10-08 07:54:43 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 12
ERROR - 2024-10-08 07:54:43 --> Severity: Warning --> Undefined variable $slider C:\xampp\htdocs\portfolio\application\views\admin\slider.php 14
ERROR - 2024-10-08 07:54:43 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 14
ERROR - 2024-10-08 07:54:43 --> Severity: Warning --> Undefined variable $slider C:\xampp\htdocs\portfolio\application\views\admin\slider.php 15
ERROR - 2024-10-08 07:54:43 --> Severity: Warning --> Attempt to read property "description" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 15
ERROR - 2024-10-08 07:57:15 --> Severity: Warning --> Undefined variable $slider C:\xampp\htdocs\portfolio\application\views\admin\slider.php 8
ERROR - 2024-10-08 07:57:15 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 8
ERROR - 2024-10-08 07:57:15 --> Severity: Warning --> Undefined variable $slider C:\xampp\htdocs\portfolio\application\views\admin\slider.php 12
ERROR - 2024-10-08 07:57:15 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 12
ERROR - 2024-10-08 07:57:15 --> Severity: Warning --> Undefined variable $slider C:\xampp\htdocs\portfolio\application\views\admin\slider.php 14
ERROR - 2024-10-08 07:57:15 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 14
ERROR - 2024-10-08 07:57:15 --> Severity: Warning --> Undefined variable $slider C:\xampp\htdocs\portfolio\application\views\admin\slider.php 15
ERROR - 2024-10-08 07:57:15 --> Severity: Warning --> Attempt to read property "description" on null C:\xampp\htdocs\portfolio\application\views\admin\slider.php 15
ERROR - 2024-10-08 07:59:53 --> Severity: Warning --> Undefined variable $sliders C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 07:59:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:02:10 --> 404 Page Not Found: Slider/save_slider
ERROR - 2024-10-08 08:02:15 --> Severity: Warning --> Undefined variable $sliders C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:02:15 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:09:56 --> 404 Page Not Found: SliderController/index
ERROR - 2024-10-08 08:10:00 --> 404 Page Not Found: SliderController/index
ERROR - 2024-10-08 08:11:02 --> 404 Page Not Found: SliderController/index
ERROR - 2024-10-08 08:11:04 --> 404 Page Not Found: SliderController/index
ERROR - 2024-10-08 08:11:10 --> 404 Page Not Found: SliderController/index
ERROR - 2024-10-08 08:11:20 --> 404 Page Not Found: Slider/index
ERROR - 2024-10-08 08:11:25 --> 404 Page Not Found: Slider/index
ERROR - 2024-10-08 08:11:42 --> 404 Page Not Found: SliderController/index
ERROR - 2024-10-08 08:11:44 --> 404 Page Not Found: SliderController/index
ERROR - 2024-10-08 08:13:23 --> Severity: Warning --> Undefined variable $sliders C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:13:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:18:25 --> Severity: Warning --> Undefined variable $sliders C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:18:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:18:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 08:18:44 --> Severity: Warning --> Undefined variable $sliders C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:18:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:18:45 --> Severity: Warning --> Undefined variable $sliders C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:18:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:18:52 --> Severity: Warning --> Undefined variable $sliders C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:18:52 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\slider.php 65
ERROR - 2024-10-08 08:24:48 --> Severity: error --> Exception: syntax error, unexpected token "if", expecting ";" or "{" C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 14
ERROR - 2024-10-08 08:25:34 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:25:34 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:25:55 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 08:26:03 --> 404 Page Not Found: Slider/delete_slider
ERROR - 2024-10-08 08:30:08 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:30:08 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:35:35 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:36:29 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:36:38 --> 404 Page Not Found: Slider/delete_slider
ERROR - 2024-10-08 08:37:09 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:38:21 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:39:33 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:42:30 --> 404 Page Not Found: Slider/save_slider
ERROR - 2024-10-08 08:42:48 --> 404 Page Not Found: Admin/slider
ERROR - 2024-10-08 08:44:24 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:44:24 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:46:04 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:46:04 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:47:02 --> 404 Page Not Found: Slider/delete_slider
ERROR - 2024-10-08 08:47:31 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 08:48:23 --> 404 Page Not Found: Slider/save_slider
ERROR - 2024-10-08 08:51:49 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:51:49 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:51:57 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 08:53:35 --> 404 Page Not Found: Slider/index
ERROR - 2024-10-08 08:53:45 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 08:54:05 --> 404 Page Not Found: Admin/manage_sliders
ERROR - 2024-10-08 08:54:15 --> 404 Page Not Found: Admin/slider
ERROR - 2024-10-08 08:55:03 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 09:00:37 --> Severity: Warning --> Undefined property: SliderController::$form_validation C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 79
ERROR - 2024-10-08 09:00:37 --> Severity: error --> Exception: Call to a member function set_rules() on null C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 79
ERROR - 2024-10-08 09:03:03 --> Severity: Warning --> Undefined property: SliderController::$form_validation C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 78
ERROR - 2024-10-08 09:03:03 --> Severity: error --> Exception: Call to a member function set_rules() on null C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 78
ERROR - 2024-10-08 09:07:47 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 09:07:47 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 09:09:24 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 09:09:30 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 09:09:31 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 09:10:32 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 09:10:34 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 09:11:16 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 09:11:16 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 09:12:47 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 09:13:05 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 09:13:05 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 09:13:14 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 09:13:21 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 10:32:02 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 10:32:04 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 10:34:08 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 10:34:08 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 10:41:21 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 10:41:37 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 10:41:37 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 10:41:38 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 10:42:22 --> 404 Page Not Found: Slider/edit
ERROR - 2024-10-08 10:43:47 --> 404 Page Not Found: Slider/edit
ERROR - 2024-10-08 10:43:52 --> 404 Page Not Found: Slider/delete
ERROR - 2024-10-08 10:44:11 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 10:44:11 --> Severity: error --> Exception: Call to undefined method Slider_model::update_slider() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 96
ERROR - 2024-10-08 10:46:56 --> 404 Page Not Found: Slider/edit
ERROR - 2024-10-08 10:47:02 --> 404 Page Not Found: Slider/delete
ERROR - 2024-10-08 10:47:09 --> 404 Page Not Found: Slider/edit
ERROR - 2024-10-08 10:47:26 --> 404 Page Not Found: Slider/edit
ERROR - 2024-10-08 10:49:40 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 10:50:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 10:50:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 10:50:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 10:56:08 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 10:56:08 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 10:56:08 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 10:56:55 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 10:57:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 10:57:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 10:57:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 10:59:28 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 10:59:31 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 10:59:34 --> 404 Page Not Found: Slider/index
ERROR - 2024-10-08 10:59:44 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:02:37 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:02:37 --> Severity: error --> Exception: Call to undefined method Slider_model::update_slider() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 97
ERROR - 2024-10-08 11:05:39 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:05:39 --> Severity: error --> Exception: Call to undefined method Slider_model::update_slider() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 97
ERROR - 2024-10-08 11:06:40 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:06:40 --> Severity: error --> Exception: Call to undefined method Slider_model::update_slider() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 97
ERROR - 2024-10-08 11:06:48 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:06:48 --> Severity: error --> Exception: Call to undefined method Slider_model::update_slider() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 97
ERROR - 2024-10-08 11:08:54 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:08:54 --> Severity: error --> Exception: Call to undefined method Slider_model::update_slider() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 97
ERROR - 2024-10-08 11:10:49 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:10:49 --> Severity: error --> Exception: Call to undefined method Slider_model::update_slider() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 97
ERROR - 2024-10-08 11:13:20 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:13:25 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:13:25 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:14:01 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:14:01 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 11:14:23 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 11:14:43 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 11:14:46 --> 404 Page Not Found: Slider/index
ERROR - 2024-10-08 11:14:48 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:14:48 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:14:49 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:15:14 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:15:15 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 11:16:39 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 11:16:46 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:16:46 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:16:47 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:17:09 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:17:09 --> 404 Page Not Found: Slider/manage_sliders
ERROR - 2024-10-08 11:17:36 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:17:43 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:18:32 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:19:02 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:19:02 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:19:08 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:19:22 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:19:22 --> Severity: error --> Exception: Call to undefined method Slider_model::update_slider() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 97
ERROR - 2024-10-08 11:25:17 --> 404 Page Not Found: Slider/index
ERROR - 2024-10-08 11:25:20 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:25:21 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:25:21 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:25:40 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:25:40 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:25:49 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:26:08 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:26:08 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:26:13 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:26:31 --> The upload path does not appear to be valid.
ERROR - 2024-10-08 11:26:31 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:26:44 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:26:47 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:30:48 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:30:48 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:30:54 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:30:54 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:31:18 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:31:18 --> 404 Page Not Found: Uploads/sliders
ERROR - 2024-10-08 11:31:23 --> 404 Page Not Found: Admin/form
ERROR - 2024-10-08 11:33:54 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-08 11:34:02 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-08 11:55:32 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 11:55:32 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 11:55:32 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-08 12:26:01 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-08 12:29:51 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-08 12:29:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 12:29:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 12:29:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 12:29:54 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-08 12:29:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 12:29:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 12:29:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 12:47:16 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-08 12:47:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 12:47:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 12:47:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 13:31:24 --> Severity: error --> Exception: Unable to locate the model you have specified: SliderModel C:\xampp\htdocs\portfolio\system\core\Loader.php 349
ERROR - 2024-10-08 13:32:21 --> Severity: error --> Exception: Unable to locate the model you have specified: SliderModel C:\xampp\htdocs\portfolio\system\core\Loader.php 349
ERROR - 2024-10-08 13:45:00 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 13:52:12 --> Severity: Compile Error --> Cannot use positional argument after named argument C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-08 13:56:29 --> Severity: error --> Exception: Call to undefined function image Not uplode() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 137
ERROR - 2024-10-08 13:59:27 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-08 13:59:30 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-08 14:05:42 --> Severity: error --> Exception: Call to undefined function Change image format() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 137
ERROR - 2024-10-08 14:07:01 --> Severity: error --> Exception: Call to undefined function Change image format() C:\xampp\htdocs\portfolio\application\controllers\SliderController.php 134
ERROR - 2024-10-08 14:14:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 14:14:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 14:14:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-08 14:14:55 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-08 14:17:23 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-08 14:17:27 --> 404 Page Not Found: Indexhtml/index
ERROR - 2024-10-08 14:17:31 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-08 14:20:24 --> 404 Page Not Found: Admin/form
ERROR - 2024-10-08 14:27:24 --> Severity: error --> Exception: syntax error, unexpected variable "$data", expecting ")" C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-08 14:27:32 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-08 14:35:48 --> 404 Page Not Found: Indexhtml/index
ERROR - 2024-10-08 14:35:51 --> 404 Page Not Found: Indexhtml/index
ERROR - 2024-10-08 14:40:47 --> 404 Page Not Found: Admin/about
ERROR - 2024-10-08 14:42:11 --> 404 Page Not Found: Index/index
ERROR - 2024-10-08 14:45:18 --> 404 Page Not Found: Admin/about

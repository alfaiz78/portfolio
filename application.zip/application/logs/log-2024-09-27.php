<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-09-27 12:19:14 --> 404 Page Not Found: Projectcontroller/index
ERROR - 2024-09-27 12:29:15 --> 404 Page Not Found: MyController/home
ERROR - 2024-09-27 12:37:02 --> 404 Page Not Found: MyController/home
ERROR - 2024-09-27 12:38:18 --> 404 Page Not Found: MyController/home
ERROR - 2024-09-27 12:38:50 --> 404 Page Not Found: MyController/index
ERROR - 2024-09-27 12:41:53 --> 404 Page Not Found: MyController/home
ERROR - 2024-09-27 12:43:06 --> 404 Page Not Found: MyController/home
ERROR - 2024-09-27 12:44:59 --> 404 Page Not Found: MyController/home
ERROR - 2024-09-27 13:00:38 --> 404 Page Not Found: MyController/index

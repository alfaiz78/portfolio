<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-15 06:34:52 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:34:53 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:34:55 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-15 06:35:21 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:35:21 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:35:28 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:35:28 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:35:41 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:35:41 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:35:47 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:35:47 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:35:49 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:35:49 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:36:00 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:36:00 --> 404 Page Not Found: Assets/uploads
ERROR - 2024-10-15 06:40:02 --> The upload path does not appear to be valid.
ERROR - 2024-10-15 06:40:02 --> The upload path does not appear to be valid.
ERROR - 2024-10-15 06:40:26 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-15 06:40:26 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-15 06:40:26 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-15 06:44:31 --> The upload path does not appear to be valid.
ERROR - 2024-10-15 06:44:31 --> The upload path does not appear to be valid.
ERROR - 2024-10-15 06:47:06 --> The upload path does not appear to be valid.
ERROR - 2024-10-15 07:01:05 --> Severity: Warning --> Undefined property: AboutController::$about_model C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 18
ERROR - 2024-10-15 07:01:05 --> Severity: error --> Exception: Call to a member function get_abouts() on null C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 18
ERROR - 2024-10-15 07:22:50 --> Severity: error --> Exception: syntax error, unexpected token "if", expecting "function" or "const" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 104
ERROR - 2024-10-15 07:30:29 --> Severity: error --> Exception: syntax error, unexpected token "if", expecting "function" or "const" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 125
ERROR - 2024-10-15 07:40:15 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\portfolio\system\database\DB_driver.php 1484
ERROR - 2024-10-15 07:40:15 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `abouts` (`title`, `bg_title`, `subtitle`, `description`, `image`, `cv`, `heading1`, `title1`, `heading2`, `title2`, `heading3`, `title3`, `heading4`, `title4`, `heading5`, `title5`, `heading6`, `title6`) VALUES (Array, 'test', 'test', 'test', 'alfaiz_(1).pdf', 'alfaiz_(1)1.pdf', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test', 'test')
ERROR - 2024-10-15 07:47:28 --> Severity: error --> Exception: Too few arguments to function About_model::add_about(), 1 passed in C:\xampp\htdocs\portfolio\application\controllers\AboutController.php on line 73 and exactly 2 expected C:\xampp\htdocs\portfolio\application\models\About_model.php 15
ERROR - 2024-10-15 07:49:18 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\portfolio\system\database\DB_driver.php 1532
ERROR - 2024-10-15 07:49:18 --> Query error: Unknown column 'subtitle' in 'field list' - Invalid query: UPDATE `abouts` SET `title` = Array, `bg_title` = 'test', `subtitle` = 'test', `description` = 'test', `image` = 'image-removebg-preview1.png', `cv` = 'alfaiz_shaikh.pdf', `heading1` = 'TEST', `title1` = 'test', `heading2` = 'test', `title2` = 'test', `heading3` = 'test', `title3` = 'test', `heading4` = 'test', `title4` = 'test', `heading5` = 'test', `title5` = 'test', `heading6` = 'test', `title6` = 'test'
WHERE `id` = 1
ERROR - 2024-10-15 07:52:58 --> Severity: error --> Exception: Too few arguments to function AboutController::save_about(), 0 passed in C:\xampp\htdocs\portfolio\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 31
ERROR - 2024-10-15 07:53:00 --> Severity: error --> Exception: Too few arguments to function AboutController::save_about(), 0 passed in C:\xampp\htdocs\portfolio\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 31
ERROR - 2024-10-15 07:53:28 --> 404 Page Not Found: AboutController/save_about
ERROR - 2024-10-15 07:54:04 --> Severity: error --> Exception: Too few arguments to function AboutController::save_about(), 0 passed in C:\xampp\htdocs\portfolio\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 31
ERROR - 2024-10-15 07:54:08 --> 404 Page Not Found: About/index
ERROR - 2024-10-15 07:55:18 --> Severity: error --> Exception: Too few arguments to function AboutController::save_about(), 0 passed in C:\xampp\htdocs\portfolio\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 31
ERROR - 2024-10-15 08:00:52 --> 404 Page Not Found: About/save_about
ERROR - 2024-10-15 08:01:58 --> Severity: error --> Exception: Too few arguments to function AboutController::update_about(), 0 passed in C:\xampp\htdocs\portfolio\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 31
ERROR - 2024-10-15 08:02:51 --> Query error: Unknown column 'subtitle' in 'field list' - Invalid query: UPDATE `abouts` SET `title` = NULL, `bg_title` = NULL, `subtitle` = NULL, `description` = NULL, `image` = NULL, `cv` = NULL, `heading1` = NULL, `title1` = NULL, `heading2` = NULL, `title2` = NULL, `heading3` = NULL, `title3` = NULL, `heading4` = NULL, `title4` = NULL, `heading5` = NULL, `title5` = NULL, `heading6` = NULL, `title6` = NULL
WHERE `id` = 1
ERROR - 2024-10-15 08:16:56 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\portfolio\system\database\DB_driver.php 1532
ERROR - 2024-10-15 08:16:56 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `abouts` SET `title` = Array, `bg_title` = 'About', `subtitle` = '120 Project complete', `description` = 'A small river named Duden flows by their place and supplies it with the necessary regelialia.', `image` = NULL, `cv` = NULL, `heading1` = NULL, `title1` = NULL, `heading2` = NULL, `title2` = NULL, `heading3` = NULL, `title3` = NULL, `heading4` = NULL, `title4` = NULL, `heading5` = NULL, `title5` = NULL, `heading6` = NULL, `title6` = NULL
WHERE `id` = 1
ERROR - 2024-10-15 08:19:24 --> 404 Page Not Found: About/index
ERROR - 2024-10-15 08:25:35 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 33
ERROR - 2024-10-15 08:25:35 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 33
ERROR - 2024-10-15 08:25:35 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 33
ERROR - 2024-10-15 08:25:40 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 33
ERROR - 2024-10-15 08:25:41 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 33
ERROR - 2024-10-15 08:32:07 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\portfolio\application\views\admin\about.php 64
ERROR - 2024-10-15 08:32:07 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\portfolio\application\views\admin\about.php 65
ERROR - 2024-10-15 08:32:07 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\portfolio\application\views\admin\about.php 69
ERROR - 2024-10-15 08:32:07 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\portfolio\application\views\admin\about.php 70
ERROR - 2024-10-15 08:32:09 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\portfolio\application\views\admin\about.php 64
ERROR - 2024-10-15 08:32:09 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\portfolio\application\views\admin\about.php 65
ERROR - 2024-10-15 08:32:09 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\portfolio\application\views\admin\about.php 69
ERROR - 2024-10-15 08:32:09 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\portfolio\application\views\admin\about.php 70
ERROR - 2024-10-15 08:32:46 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\portfolio\application\views\admin\about.php 65
ERROR - 2024-10-15 08:32:46 --> Severity: Warning --> Undefined variable $i C:\xampp\htdocs\portfolio\application\views\admin\about.php 70
ERROR - 2024-10-15 08:39:37 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-15 08:39:37 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-15 08:39:37 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-15 09:11:50 --> Severity: Compile Error --> Cannot redeclare AboutController::update_about() C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 74
ERROR - 2024-10-15 10:47:22 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 40
ERROR - 2024-10-15 10:47:22 --> Severity: Warning --> Undefined array key "cv" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 41
ERROR - 2024-10-15 11:26:53 --> Severity: Warning --> Undefined property: Mycontroller::$About_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-15 11:26:53 --> Severity: error --> Exception: Call to a member function get_abouts() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-15 11:27:24 --> Severity: Warning --> Undefined property: Mycontroller::$about_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-15 11:27:24 --> Severity: error --> Exception: Call to a member function get_abouts() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-15 11:27:27 --> Severity: Warning --> Undefined property: Mycontroller::$about_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-15 11:27:27 --> Severity: error --> Exception: Call to a member function get_abouts() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-15 11:28:10 --> Severity: Warning --> Undefined property: Mycontroller::$About_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-15 11:28:10 --> Severity: error --> Exception: Call to a member function get_abouts() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 47
ERROR - 2024-10-15 11:29:58 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\portfolio\application\controllers\MyController.php 51
ERROR - 2024-10-15 11:30:32 --> Severity: error --> Exception: Call to undefined function print_f() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 51
ERROR - 2024-10-15 11:53:15 --> Severity: Warning --> Undefined property: stdClass::$discribtion C:\xampp\htdocs\portfolio\application\views\index.php 114
ERROR - 2024-10-15 11:53:30 --> Severity: Warning --> Undefined property: stdClass::$discription C:\xampp\htdocs\portfolio\application\views\index.php 114
ERROR - 2024-10-15 12:03:37 --> Severity: Warning --> Undefined property: stdClass::$subdigit C:\xampp\htdocs\portfolio\application\views\admin\about.php 97
ERROR - 2024-10-15 12:39:15 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting "function" or "const" C:\xampp\htdocs\portfolio\application\controllers\MyController.php 136
ERROR - 2024-10-15 12:39:44 --> Severity: error --> Exception: syntax error, unexpected token ":", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 132
ERROR - 2024-10-15 12:39:55 --> Severity: error --> Exception: syntax error, unexpected token ":", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 120
ERROR - 2024-10-15 12:59:57 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 108
ERROR - 2024-10-15 13:10:20 --> 404 Page Not Found: Admin/calendar
ERROR - 2024-10-15 13:13:28 --> 404 Page Not Found: Contact-section/index
ERROR - 2024-10-15 13:13:48 --> 404 Page Not Found: Contact-section/index
ERROR - 2024-10-15 13:16:46 --> 404 Page Not Found: AboutController/resume
ERROR - 2024-10-15 13:19:05 --> 404 Page Not Found: AboutController/resume
ERROR - 2024-10-15 13:22:29 --> 404 Page Not Found: AboutController/resume
ERROR - 2024-10-15 13:23:00 --> 404 Page Not Found: ResumeController/resume
ERROR - 2024-10-15 13:23:01 --> 404 Page Not Found: ResumeController/resume
ERROR - 2024-10-15 13:23:08 --> 404 Page Not Found: ResumeController/resume
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:24:42 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:06 --> 404 Page Not Found: Admin/calendar.html
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:25:08 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-15 13:28:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-15 13:29:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-15 14:28:17 --> 404 Page Not Found: Admin/calendar
ERROR - 2024-10-15 14:29:47 --> 404 Page Not Found: Assets/js

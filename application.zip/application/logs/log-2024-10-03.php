<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-03 06:19:12 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 06:19:12 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 06:19:12 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 06:19:38 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 06:19:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 06:19:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 06:21:14 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 06:22:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 06:22:20 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 06:22:20 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 06:22:20 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 06:22:28 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 08:33:04 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 08:33:05 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 08:33:05 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 08:35:42 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 08:35:42 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 08:35:42 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 08:35:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 08:35:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 08:35:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 08:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 08:47:47 --> 404 Page Not Found: Calendarphp/index
ERROR - 2024-10-03 08:47:48 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 08:57:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 09:08:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 09:08:58 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 09:09:52 --> Severity: Compile Error --> Cannot redeclare Mycontroller::admin() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 90
ERROR - 2024-10-03 09:09:58 --> Severity: Compile Error --> Cannot redeclare Mycontroller::admin() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 90
ERROR - 2024-10-03 09:11:11 --> 404 Page Not Found: MyController/admin
ERROR - 2024-10-03 09:11:13 --> 404 Page Not Found: MyController/admin
ERROR - 2024-10-03 09:11:29 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 09:11:29 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 09:11:29 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 09:11:38 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 09:11:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 09:11:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 09:18:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 09:18:55 --> Unable to connect to the database
ERROR - 2024-10-03 09:18:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 09:18:58 --> Unable to connect to the database
ERROR - 2024-10-03 09:18:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 09:18:59 --> Unable to connect to the database
ERROR - 2024-10-03 09:20:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 09:20:47 --> Unable to connect to the database
ERROR - 2024-10-03 09:20:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 09:20:49 --> Unable to connect to the database
ERROR - 2024-10-03 09:22:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 09:22:40 --> Unable to connect to the database
ERROR - 2024-10-03 09:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 09:25:21 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 09:25:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 09:25:56 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 09:26:13 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 09:26:18 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 09:26:37 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 09:28:24 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 10:49:34 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\portfolio\application\controllers\MyController.php 73
ERROR - 2024-10-03 10:49:35 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\portfolio\application\controllers\MyController.php 73
ERROR - 2024-10-03 10:49:36 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\portfolio\application\controllers\MyController.php 73
ERROR - 2024-10-03 10:50:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 10:50:54 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 10:52:50 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 10:52:56 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 10:57:05 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 10:57:12 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 11:00:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:01:03 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 11:01:52 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 11:10:47 --> 404 Page Not Found: Login/process
ERROR - 2024-10-03 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:16:08 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 123
ERROR - 2024-10-03 11:16:11 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 123
ERROR - 2024-10-03 11:16:13 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\MyController.php 123
ERROR - 2024-10-03 11:16:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 11:16:40 --> Unable to connect to the database
ERROR - 2024-10-03 11:16:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 11:16:42 --> Unable to connect to the database
ERROR - 2024-10-03 11:16:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 11:16:42 --> Unable to connect to the database
ERROR - 2024-10-03 11:17:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 11:17:42 --> Unable to connect to the database
ERROR - 2024-10-03 11:17:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 11:17:44 --> Unable to connect to the database
ERROR - 2024-10-03 11:17:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-03 11:17:54 --> Unable to connect to the database
ERROR - 2024-10-03 11:20:37 --> Severity: error --> Exception: Unmatched ')' C:\xampp\htdocs\portfolio\application\config\database.php 98
ERROR - 2024-10-03 11:22:55 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:23:01 --> Query error: Table 'portfolio.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` = 'alfaiz'
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
ERROR - 2024-10-03 11:23:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:24:11 --> Query error: Table 'portfolio.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` = 'alfaiz'
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
ERROR - 2024-10-03 11:35:37 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:35:41 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:35:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:35:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:36:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:36:29 --> 404 Page Not Found: MyController/home
ERROR - 2024-10-03 11:38:22 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:38:36 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:38:43 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:49:25 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:49:29 --> 404 Page Not Found: MyController/home
ERROR - 2024-10-03 11:50:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:50:13 --> 404 Page Not Found: MyController/home
ERROR - 2024-10-03 11:50:56 --> 404 Page Not Found: MyController/home
ERROR - 2024-10-03 11:56:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:56:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:56:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:56:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:11 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:57:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:28 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:28 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:28 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:28 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:28 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:28 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:28 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:28 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:28 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:33 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:57:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:57:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:57:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 11:57:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 11:57:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:03:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:03:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:03:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:03:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:03:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:04:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:04:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:04:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:05:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:05:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:05:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:05:50 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:05:50 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:05:50 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:17:40 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:17:46 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:17:46 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:17:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:17:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:17:59 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:18:11 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:18:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:18:29 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:18:29 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:18:29 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:19:07 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:19:07 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:19:07 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:23:06 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:23:06 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:23:06 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:25:56 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:26:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:12 --> 404 Page Not Found: Hero/index
ERROR - 2024-10-03 12:26:17 --> 404 Page Not Found: Heme/index
ERROR - 2024-10-03 12:26:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:43 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:43 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:43 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:26:46 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:27:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:27:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:27:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:30:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:30:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:30:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:33:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:33:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:33:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:33:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:55 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:55 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:55 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:55 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:56 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:56 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:56 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:56 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:58 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:58 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:58 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:36:58 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:37:15 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:39:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:39:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:39:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:39:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:43:21 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:43:21 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:43:29 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:43:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:43:47 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:43:51 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:43:51 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:44:11 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:44:20 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:44:27 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:44:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:44:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:47:03 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:47:03 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:47:11 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 12:50:14 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:50:14 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:53:33 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:53:33 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:58:04 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:58:04 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 12:58:09 --> 404 Page Not Found: Admin/logout
ERROR - 2024-10-03 13:00:31 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:00:38 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:00:38 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:00:42 --> 404 Page Not Found: Admin/logout
ERROR - 2024-10-03 13:02:07 --> 404 Page Not Found: Admin/logout
ERROR - 2024-10-03 13:02:17 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:02:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:02:23 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:02:28 --> 404 Page Not Found: Admin/logout
ERROR - 2024-10-03 13:05:19 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:05:19 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:05:41 --> 404 Page Not Found: Admin/logout
ERROR - 2024-10-03 13:09:00 --> 404 Page Not Found: MyController/index
ERROR - 2024-10-03 13:09:00 --> 404 Page Not Found: MyController/index
ERROR - 2024-10-03 13:09:03 --> 404 Page Not Found: MyController/index
ERROR - 2024-10-03 13:09:32 --> 404 Page Not Found: MyController/index
ERROR - 2024-10-03 13:11:21 --> 404 Page Not Found: Log/index
ERROR - 2024-10-03 13:11:25 --> 404 Page Not Found: MyController/index
ERROR - 2024-10-03 13:11:25 --> 404 Page Not Found: MyController/index
ERROR - 2024-10-03 13:11:38 --> 404 Page Not Found: MyController/index
ERROR - 2024-10-03 13:11:39 --> 404 Page Not Found: MyController/index
ERROR - 2024-10-03 13:12:20 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:12:20 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:12:28 --> 404 Page Not Found: Admin/logout
ERROR - 2024-10-03 13:13:01 --> 404 Page Not Found: MyController/admin
ERROR - 2024-10-03 13:13:03 --> 404 Page Not Found: Home/index
ERROR - 2024-10-03 13:13:07 --> 404 Page Not Found: Home/index
ERROR - 2024-10-03 13:13:10 --> 404 Page Not Found: MyController/admin
ERROR - 2024-10-03 13:13:12 --> 404 Page Not Found: MyController/admin
ERROR - 2024-10-03 13:13:15 --> 404 Page Not Found: MyController/admin
ERROR - 2024-10-03 13:13:18 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:13:24 --> 404 Page Not Found: MyController/admin
ERROR - 2024-10-03 13:14:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:14:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:14:11 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:14:36 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:14:42 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:14:42 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:15:03 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:15:09 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:15:09 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:15:38 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:15:42 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:15:42 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:15:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:15:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:15:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:16:05 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:16:10 --> 404 Page Not Found: 1234586/index
ERROR - 2024-10-03 13:18:39 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:18:45 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:18:45 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:18:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:25:10 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:25:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:25:26 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:25:26 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:25:30 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:25:38 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:25:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:25:54 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:26:43 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:26:43 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:26:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:26:58 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:34:06 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:34:15 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:34:30 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:34:38 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:34:38 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:34:43 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:34:58 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:34:58 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:35:03 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:35:11 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:35:20 --> 404 Page Not Found: Registerhtml/index
ERROR - 2024-10-03 13:35:27 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:35:59 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:35:59 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:36:45 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:36:45 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:36:49 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:36:49 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:36:53 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:36:58 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:36:58 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:37:29 --> 404 Page Not Found: Admin/icons
ERROR - 2024-10-03 13:37:30 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:37:37 --> 404 Page Not Found: Admin/icons
ERROR - 2024-10-03 13:37:49 --> 404 Page Not Found: Admin/icons
ERROR - 2024-10-03 13:37:53 --> 404 Page Not Found: Assets/images
ERROR - 2024-10-03 13:37:57 --> 404 Page Not Found: Assets/images
ERROR - 2024-10-03 13:38:16 --> 404 Page Not Found: Assets/images
ERROR - 2024-10-03 13:38:18 --> 404 Page Not Found: Assets/images
ERROR - 2024-10-03 13:38:24 --> 404 Page Not Found: Calendar/index
ERROR - 2024-10-03 13:38:29 --> 404 Page Not Found: Assets/images
ERROR - 2024-10-03 13:38:33 --> 404 Page Not Found: Assets/images
ERROR - 2024-10-03 13:38:38 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:38:38 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:38:41 --> 404 Page Not Found: Admin/icons
ERROR - 2024-10-03 13:40:12 --> 404 Page Not Found: Admin/assets
ERROR - 2024-10-03 13:40:14 --> 404 Page Not Found: Assets/images
ERROR - 2024-10-03 13:40:19 --> 404 Page Not Found: Admin/profile
ERROR - 2024-10-03 13:41:27 --> 404 Page Not Found: Admin/admin
ERROR - 2024-10-03 13:42:15 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:42:15 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:42:22 --> 404 Page Not Found: Admin/logout
ERROR - 2024-10-03 13:42:30 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:42:31 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:42:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:42:43 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:42:43 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:42:47 --> 404 Page Not Found: Admin/logout
ERROR - 2024-10-03 13:43:25 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:43:25 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:43:30 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:43:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:43:38 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:43:46 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:43:46 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:43:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:44:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:44:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:46:43 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:46:43 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:47:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:47:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:48:08 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:51:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:52:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:52:47 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:53:01 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:53:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:54:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:54:18 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:54:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:54:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:54:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:54:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 13:54:58 --> 404 Page Not Found: Admin/register
ERROR - 2024-10-03 13:56:34 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:56:34 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:56:34 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:56:41 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:56:41 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 13:56:41 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:00:41 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:00:53 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:03:20 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:03:20 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:10:54 --> Severity: Compile Error --> Cannot redeclare Mycontroller::__construct() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 65
ERROR - 2024-10-03 14:12:02 --> Severity: Compile Error --> Cannot redeclare Mycontroller::login() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 70
ERROR - 2024-10-03 14:12:05 --> Severity: Compile Error --> Cannot redeclare Mycontroller::login() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 70
ERROR - 2024-10-03 14:12:06 --> Severity: Compile Error --> Cannot redeclare Mycontroller::login() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 70
ERROR - 2024-10-03 14:12:33 --> Severity: Compile Error --> Cannot redeclare Mycontroller::logout() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 108
ERROR - 2024-10-03 14:13:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:13:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:13:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:13:22 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:13:45 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:13:45 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:13:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:14:04 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:14:21 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:14:21 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:14:25 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:14:25 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:16:58 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:19:25 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:19:35 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:19:35 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:45:30 --> 404 Page Not Found: Home/index
ERROR - 2024-10-03 14:45:38 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:45:38 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:45:46 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:45:59 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:46:08 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:46:26 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:46:26 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:46:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:46:50 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:46:50 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-03 14:46:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-03 14:47:09 --> 404 Page Not Found: Assets/js

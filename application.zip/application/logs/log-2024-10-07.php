<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-07 19:47:28 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 19:47:38 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 19:47:53 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 19:47:58 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 19:48:20 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 19:48:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 19:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 19:56:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-07 19:56:33 --> Unable to connect to the database
ERROR - 2024-10-07 19:56:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-07 19:56:35 --> Unable to connect to the database
ERROR - 2024-10-07 19:58:56 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 19:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 20:15:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'portfolio' C:\xampp\htdocs\portfolio\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2024-10-07 20:15:45 --> Unable to connect to the database
ERROR - 2024-10-07 20:50:17 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 20:50:22 --> Query error: Table 'portfolio.users' doesn't exist in engine - Invalid query: SELECT *
FROM `users`
WHERE `password` = 'e10adc3949ba59abbe56e057f20f883e'
AND   (
`username` = 'alfaiz'
OR `email` = 'alfaiz'
 )
ERROR - 2024-10-07 21:02:05 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 21:03:05 --> 404 Page Not Found: Assets/images
ERROR - 2024-10-07 21:03:23 --> 404 Page Not Found: Admin/icons
ERROR - 2024-10-07 21:03:54 --> 404 Page Not Found: Admin/icons
ERROR - 2024-10-07 21:12:48 --> 404 Page Not Found: Assets/images
ERROR - 2024-10-07 21:12:50 --> 404 Page Not Found: Admin/icons
ERROR - 2024-10-07 21:14:45 --> 404 Page Not Found: Index/index
ERROR - 2024-10-07 21:23:55 --> Severity: Warning --> Undefined variable $user_input C:\xampp\htdocs\portfolio\application\views\admin\header.php 99
ERROR - 2024-10-07 21:24:59 --> Severity: Warning --> Undefined variable $user_input C:\xampp\htdocs\portfolio\application\views\admin\header.php 99
ERROR - 2024-10-07 21:24:59 --> Severity: error --> Exception: Object of class CI_Input could not be converted to string C:\xampp\htdocs\portfolio\application\views\admin\header.php 99
ERROR - 2024-10-07 21:39:15 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 21:39:21 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 21:39:21 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 21:41:25 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 22:37:29 --> 404 Page Not Found: Index/index
ERROR - 2024-10-07 22:37:31 --> 404 Page Not Found: Index/index
ERROR - 2024-10-07 23:17:24 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\xampp\htdocs\portfolio\application\controllers\MyController.php 86
ERROR - 2024-10-07 23:17:26 --> Severity: error --> Exception: syntax error, unexpected token "else" C:\xampp\htdocs\portfolio\application\controllers\MyController.php 86
ERROR - 2024-10-07 23:17:53 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:17:58 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:18:05 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:18:34 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting ")" C:\xampp\htdocs\portfolio\application\controllers\MyController.php 75
ERROR - 2024-10-07 23:18:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:18:50 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:18:56 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:19:13 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:19:47 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:20:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:20:22 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:20:27 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:21:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:21:53 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:22:40 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:24:01 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:24:05 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:24:09 --> Severity: error --> Exception: Too few arguments to function User_model::get_user_by_username_or_email(), 1 passed in C:\xampp\htdocs\portfolio\application\controllers\MyController.php on line 71 and exactly 2 expected C:\xampp\htdocs\portfolio\application\models\User_model.php 13
ERROR - 2024-10-07 23:25:42 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:25:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:26:17 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:26:20 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:26:20 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:26:25 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:26:33 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:26:40 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:29:36 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:29:36 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:31:18 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:31:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:34:37 --> Severity: error --> Exception: Call to undefined method CI_Session::emaildata() C:\xampp\htdocs\portfolio\application\views\admin\header.php 135
ERROR - 2024-10-07 23:37:04 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:37:10 --> Severity: Warning --> session_write_close(): Skipping numeric key 0 Unknown 0
ERROR - 2024-10-07 23:40:27 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:40:31 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:41:27 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:42:30 --> Severity: Warning --> session_write_close(): Skipping numeric key 0 Unknown 0
ERROR - 2024-10-07 23:42:39 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:42:45 --> Severity: Warning --> session_write_close(): Skipping numeric key 0 Unknown 0
ERROR - 2024-10-07 23:43:47 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:43:52 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\portfolio\application\controllers\MyController.php 75
ERROR - 2024-10-07 23:44:17 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:44:22 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\portfolio\application\controllers\MyController.php 75
ERROR - 2024-10-07 23:45:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:45:41 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\portfolio\application\controllers\MyController.php 75
ERROR - 2024-10-07 23:46:35 --> Severity: error --> Exception: Call to undefined method Mycontroller::login() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 46
ERROR - 2024-10-07 23:46:37 --> Severity: error --> Exception: Call to undefined method Mycontroller::login() C:\xampp\htdocs\portfolio\application\controllers\MyController.php 46
ERROR - 2024-10-07 23:46:40 --> 404 Page Not Found: MyController/login
ERROR - 2024-10-07 23:46:41 --> 404 Page Not Found: MyController/login
ERROR - 2024-10-07 23:46:52 --> 404 Page Not Found: MyController/login
ERROR - 2024-10-07 23:46:53 --> 404 Page Not Found: MyController/login
ERROR - 2024-10-07 23:47:04 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:47:07 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\xampp\htdocs\portfolio\application\controllers\MyController.php 75
ERROR - 2024-10-07 23:47:39 --> Severity: error --> Exception: Unclosed '{' on line 73 does not match ')' C:\xampp\htdocs\portfolio\application\controllers\MyController.php 75
ERROR - 2024-10-07 23:47:45 --> 404 Page Not Found: Login/admin
ERROR - 2024-10-07 23:47:59 --> 404 Page Not Found: Login/admin
ERROR - 2024-10-07 23:48:00 --> 404 Page Not Found: Login/admin
ERROR - 2024-10-07 23:48:01 --> 404 Page Not Found: Login/admin
ERROR - 2024-10-07 23:48:03 --> 404 Page Not Found: Login/admin
ERROR - 2024-10-07 23:48:06 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:48:06 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:48:22 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:48:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:48:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:49:28 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:49:38 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 23:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-07 12:46:35 --> 404 Page Not Found: Admin/slider
ERROR - 2024-10-07 12:57:59 --> 404 Page Not Found: Assets/js

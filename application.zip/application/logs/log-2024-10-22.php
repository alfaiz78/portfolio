<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-22 06:38:21 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 06:38:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 06:38:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 06:39:02 --> 404 Page Not Found: Admin/contact
ERROR - 2024-10-22 06:41:44 --> 404 Page Not Found: Admin/contact
ERROR - 2024-10-22 06:47:34 --> 404 Page Not Found: Admin/contact
ERROR - 2024-10-22 06:57:30 --> 404 Page Not Found: ContactController/contact
ERROR - 2024-10-22 07:01:16 --> Severity: error --> Exception: syntax error, unexpected token ",", expecting ")" C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 22
ERROR - 2024-10-22 07:01:31 --> Severity: error --> Exception: C:\xampp\htdocs\portfolio\application\models/Contact_model.php exists, but doesn't declare class Contact_model C:\xampp\htdocs\portfolio\system\core\Loader.php 341
ERROR - 2024-10-22 07:25:39 --> Severity: Warning --> Undefined variable $hservices C:\xampp\htdocs\portfolio\application\views\admin\contact.php 23
ERROR - 2024-10-22 07:25:39 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\contact.php 23
ERROR - 2024-10-22 07:30:32 --> Severity: Warning --> Undefined variable $hservices C:\xampp\htdocs\portfolio\application\views\admin\contact.php 23
ERROR - 2024-10-22 07:30:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\contact.php 23
ERROR - 2024-10-22 07:30:44 --> Severity: Warning --> Undefined variable $hservices C:\xampp\htdocs\portfolio\application\views\admin\contact.php 23
ERROR - 2024-10-22 07:30:44 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\contact.php 23
ERROR - 2024-10-22 07:31:31 --> Severity: Warning --> Undefined property: ContactController::$Contact_model C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:31:31 --> Severity: error --> Exception: Call to a member function get_hcontacts() on null C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:40:13 --> Severity: Warning --> Undefined property: ContactController::$Contact_model C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:40:13 --> Severity: error --> Exception: Call to a member function get_hcontacts() on null C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:40:16 --> Severity: Warning --> Undefined property: ContactController::$Contact_model C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:40:16 --> Severity: error --> Exception: Call to a member function get_hcontacts() on null C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:41:54 --> Severity: Warning --> Undefined property: ContactController::$Contact_model C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:41:54 --> Severity: error --> Exception: Call to a member function get_hcontacts() on null C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:42:29 --> Severity: Warning --> Undefined property: ContactController::$Contact_model C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:42:29 --> Severity: error --> Exception: Call to a member function get_hcontacts() on null C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:42:30 --> Severity: Warning --> Undefined property: ContactController::$Contact_model C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:42:30 --> Severity: error --> Exception: Call to a member function get_hcontacts() on null C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:42:32 --> Severity: Warning --> Undefined property: ContactController::$Contact_model C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:42:32 --> Severity: error --> Exception: Call to a member function get_hcontacts() on null C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 18
ERROR - 2024-10-22 07:59:46 --> 404 Page Not Found: Admin/contact
ERROR - 2024-10-22 07:59:53 --> 404 Page Not Found: Admin/contact
ERROR - 2024-10-22 08:00:07 --> 404 Page Not Found: Admin/header
ERROR - 2024-10-22 08:11:54 --> Query error: Unknown column 'description' in 'field list' - Invalid query: INSERT INTO `contacts` (`icon`, `title`, `description`) VALUES ('fal fa-aperture', 'alfaiz', 'hello')
ERROR - 2024-10-22 08:14:13 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\contact.php 125
ERROR - 2024-10-22 08:15:33 --> 404 Page Not Found: Contact/manage_Contacts
ERROR - 2024-10-22 08:15:49 --> 404 Page Not Found: Contact/manage_Contacts
ERROR - 2024-10-22 08:21:55 --> 404 Page Not Found: Contact/index
ERROR - 2024-10-22 08:22:23 --> 404 Page Not Found: Contact/manage_contact
ERROR - 2024-10-22 08:22:30 --> 404 Page Not Found: Manage_contact/1
ERROR - 2024-10-22 08:22:37 --> 404 Page Not Found: Manage_contact/1
ERROR - 2024-10-22 08:27:57 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 39
ERROR - 2024-10-22 08:28:03 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 39
ERROR - 2024-10-22 08:29:01 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 39
ERROR - 2024-10-22 08:30:21 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 39
ERROR - 2024-10-22 08:31:15 --> Query error: Unknown column 'description' in 'field list' - Invalid query: UPDATE `contacts` SET `icon` = 'fal fa-camera-retro', `title` = 'hELLO', `description` = 'xlligent'
WHERE `id` = '3'
ERROR - 2024-10-22 08:49:29 --> 404 Page Not Found: ContactController/update_contact
ERROR - 2024-10-22 08:51:17 --> Severity: error --> Exception: Too few arguments to function ContactController::update_hcontact(), 0 passed in C:\xampp\htdocs\portfolio\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 136
ERROR - 2024-10-22 08:52:37 --> 404 Page Not Found: ContactController/update_contact
ERROR - 2024-10-22 08:53:28 --> Severity: error --> Exception: Too few arguments to function ContactController::update_hcontact(), 0 passed in C:\xampp\htdocs\portfolio\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 136
ERROR - 2024-10-22 08:54:49 --> Severity: Warning --> Undefined property: ContactController::$upload C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 158
ERROR - 2024-10-22 08:54:49 --> Severity: error --> Exception: Call to a member function initialize() on null C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 158
ERROR - 2024-10-22 08:57:08 --> 404 Page Not Found: ContactController/update_contact
ERROR - 2024-10-22 08:57:10 --> 404 Page Not Found: ContactController/update_contact
ERROR - 2024-10-22 08:59:38 --> Severity: Warning --> Undefined property: ContactController::$upload C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 158
ERROR - 2024-10-22 08:59:38 --> Severity: error --> Exception: Call to a member function initialize() on null C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 158
ERROR - 2024-10-22 09:14:54 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-22 10:56:14 --> 404 Page Not Found: Index/index
ERROR - 2024-10-22 10:59:06 --> 404 Page Not Found: Index/index
ERROR - 2024-10-22 11:02:16 --> 404 Page Not Found: Index/index
ERROR - 2024-10-22 11:24:24 --> Severity: error --> Exception: Call to undefined method CI_Loader::conteoller() C:\xampp\htdocs\portfolio\application\controllers\ContactController.php 13
ERROR - 2024-10-22 12:38:17 --> 404 Page Not Found: Admin/send_email
ERROR - 2024-10-22 12:39:47 --> 404 Page Not Found: Admin/email_form
ERROR - 2024-10-22 12:40:21 --> 404 Page Not Found: Admin/email_form
ERROR - 2024-10-22 12:46:39 --> Severity: Notice --> fwrite(): Send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host C:\xampp\htdocs\portfolio\system\libraries\Email.php 2269
ERROR - 2024-10-22 12:46:39 --> 404 Page Not Found: Index/index
ERROR - 2024-10-22 12:46:58 --> 404 Page Not Found: Index/index
ERROR - 2024-10-22 12:53:09 --> Severity: Notice --> fwrite(): Send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host C:\xampp\htdocs\portfolio\system\libraries\Email.php 2269
ERROR - 2024-10-22 12:53:09 --> 404 Page Not Found: Index/index
ERROR - 2024-10-22 12:58:41 --> Severity: Notice --> fwrite(): Send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host C:\xampp\htdocs\portfolio\system\libraries\Email.php 2269
ERROR - 2024-10-22 12:58:41 --> 404 Page Not Found: Index/index
ERROR - 2024-10-22 13:02:42 --> 404 Page Not Found: Images/about.jpg
ERROR - 2024-10-22 13:20:25 --> Severity: Notice --> fwrite(): Send of 6 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host C:\xampp\htdocs\portfolio\system\libraries\Email.php 2269
ERROR - 2024-10-22 13:31:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:31:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:31:32 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-22 13:31:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:31:59 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-22 13:32:00 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:32:00 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:32:00 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:33:07 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-22 13:33:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:33:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:33:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:34:49 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-22 13:34:50 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:34:50 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:34:50 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-22 13:48:51 --> Severity: Warning --> session_start(): Failed to decode session object. Session has been destroyed C:\xampp\htdocs\portfolio\system\libraries\Session\Session.php 137
ERROR - 2024-10-22 13:48:53 --> 404 Page Not Found: Assets/js

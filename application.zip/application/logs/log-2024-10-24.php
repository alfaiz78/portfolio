<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-24 08:19:41 --> Severity: error --> Exception: Unable to locate the model you have specified: ContactModel C:\xampp\htdocs\portfolio\system\core\Loader.php 349
ERROR - 2024-10-24 08:21:15 --> Severity: error --> Exception: Array callback must have exactly two elements C:\xampp\htdocs\portfolio\application\controllers\MyController.php 62
ERROR - 2024-10-24 08:22:32 --> Severity: Warning --> Undefined property: Mycontroller::$Contact_model C:\xampp\htdocs\portfolio\application\controllers\MyController.php 62
ERROR - 2024-10-24 08:22:32 --> Severity: error --> Exception: Call to a member function get_hcontacts() on null C:\xampp\htdocs\portfolio\application\controllers\MyController.php 62
ERROR - 2024-10-24 10:57:09 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-24 10:57:10 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-24 10:57:34 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-24 11:13:37 --> 404 Page Not Found: Admin/admin
ERROR - 2024-10-24 11:13:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Footer_model C:\xampp\htdocs\portfolio\system\core\Loader.php 349
ERROR - 2024-10-24 11:15:06 --> Severity: error --> Exception: C:\xampp\htdocs\portfolio\application\models/Footer_model.php exists, but doesn't declare class Footer_model C:\xampp\htdocs\portfolio\system\core\Loader.php 341
ERROR - 2024-10-24 11:15:08 --> Severity: error --> Exception: C:\xampp\htdocs\portfolio\application\models/Footer_model.php exists, but doesn't declare class Footer_model C:\xampp\htdocs\portfolio\system\core\Loader.php 341
ERROR - 2024-10-24 11:16:37 --> Query error: Table 'portfolio.footers' doesn't exist - Invalid query: SELECT *
FROM `footers`
ERROR - 2024-10-24 11:18:35 --> Query error: Table 'portfolio.footers' doesn't exist - Invalid query: SELECT *
FROM `footers`
ERROR - 2024-10-24 11:22:43 --> 404 Page Not Found: Admin/site-settings
ERROR - 2024-10-24 11:25:09 --> Query error: Table 'portfolio.footers' doesn't exist - Invalid query: SELECT *
FROM `footers`
ERROR - 2024-10-24 11:28:32 --> Query error: Table 'portfolio.navbars' doesn't exist - Invalid query: SELECT *
FROM `navbars`
ERROR - 2024-10-24 11:29:41 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 58
ERROR - 2024-10-24 11:29:41 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 61
ERROR - 2024-10-24 11:30:50 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 58
ERROR - 2024-10-24 11:30:50 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 61
ERROR - 2024-10-24 13:14:18 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 58
ERROR - 2024-10-24 13:14:18 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 61
ERROR - 2024-10-24 13:21:31 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 58
ERROR - 2024-10-24 13:21:31 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 61
ERROR - 2024-10-24 13:22:30 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 58
ERROR - 2024-10-24 13:22:30 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 61
ERROR - 2024-10-24 13:22:33 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 58
ERROR - 2024-10-24 13:22:33 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 61
ERROR - 2024-10-24 13:22:42 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 58
ERROR - 2024-10-24 13:22:42 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 61
ERROR - 2024-10-24 13:25:22 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 13:25:22 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 13:26:17 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 13:26:17 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 80
ERROR - 2024-10-24 13:26:34 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 13:26:34 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 80
ERROR - 2024-10-24 13:28:03 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 13:28:03 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 80
ERROR - 2024-10-24 13:28:21 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 13:28:21 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 80
ERROR - 2024-10-24 13:28:31 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 13:28:31 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 80
ERROR - 2024-10-24 13:28:35 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 13:28:35 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 80
ERROR - 2024-10-24 14:10:56 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:10:56 --> Severity: Warning --> Attempt to read property "subtitle" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 80
ERROR - 2024-10-24 14:13:43 --> Severity: Warning --> Undefined variable $footers C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:13:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:14:51 --> Severity: Warning --> Undefined variable $footers C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:14:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:16:01 --> Severity: Warning --> Undefined variable $footers C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:16:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:17:15 --> Severity: Warning --> Undefined variable $footers C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:18:38 --> Severity: Warning --> Undefined variable $foters C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:18:38 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 74
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 77
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 82
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 86
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 74
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 77
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 82
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 86
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 74
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 77
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 82
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 86
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 74
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 77
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 82
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 86
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 74
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 77
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 82
ERROR - 2024-10-24 14:18:50 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 86
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 74
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 77
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 82
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 74
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 77
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 82
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 74
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 77
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 82
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 74
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 77
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 82
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 74
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 77
ERROR - 2024-10-24 14:21:46 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 82
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:23:16 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:24:21 --> Severity: Warning --> Undefined variable $footers C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:24:21 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 71
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 84
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 84
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 84
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 84
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 14:25:19 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 84
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 84
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 88
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 84
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 88
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 84
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 88
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 84
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 88
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 76
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 79
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 84
ERROR - 2024-10-24 14:31:48 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 88
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:33:10 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:34:17 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 75
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "title" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 78
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "subtitle" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 83
ERROR - 2024-10-24 14:35:19 --> Severity: Warning --> Attempt to read property "id" on string C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 87
ERROR - 2024-10-24 14:38:05 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 83
ERROR - 2024-10-24 14:38:26 --> Severity: error --> Exception: Call to undefined method Footer_model::get_footer() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 19
ERROR - 2024-10-24 14:38:29 --> Severity: error --> Exception: Call to undefined method Footer_model::get_footer() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 19
ERROR - 2024-10-24 17:21:28 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-24 17:21:29 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-24 17:28:26 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 25
ERROR - 2024-10-24 17:30:22 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::update_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 116
ERROR - 2024-10-24 17:31:12 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::delete_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 118
ERROR - 2024-10-24 17:31:15 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::delete_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 118
ERROR - 2024-10-24 17:31:15 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::delete_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 118
ERROR - 2024-10-24 17:31:17 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::delete_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 118
ERROR - 2024-10-24 17:31:17 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::delete_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 118
ERROR - 2024-10-24 17:31:18 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::delete_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 118
ERROR - 2024-10-24 17:31:19 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::delete_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 118
ERROR - 2024-10-24 17:31:19 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::delete_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 118
ERROR - 2024-10-24 17:31:20 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::delete_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 118
ERROR - 2024-10-24 17:39:03 --> Severity: Compile Error --> Cannot redeclare SiteSettingsController::update_navbar() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 116
ERROR - 2024-10-24 17:41:54 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
ERROR - 2024-10-24 17:42:53 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:46:24 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:46:26 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:46:27 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:51:16 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:51:18 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:51:18 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:51:19 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:51:20 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:51:21 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:53:17 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:53:18 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:53:18 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:53:18 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 17:53:18 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 18:01:04 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 117
ERROR - 2024-10-24 18:04:23 --> 404 Page Not Found: Add-navbar/index
ERROR - 2024-10-24 18:04:23 --> 404 Page Not Found: Add-navbar/index
ERROR - 2024-10-24 19:26:25 --> Severity: error --> Exception: syntax error, unexpected variable "$route" C:\xampp\htdocs\portfolio\application\config\routes.php 83
ERROR - 2024-10-24 19:26:27 --> Severity: error --> Exception: syntax error, unexpected variable "$route" C:\xampp\htdocs\portfolio\application\config\routes.php 83
ERROR - 2024-10-24 19:26:30 --> Severity: error --> Exception: syntax error, unexpected variable "$route" C:\xampp\htdocs\portfolio\application\config\routes.php 83
ERROR - 2024-10-24 19:31:10 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
 LIMIT 1
ERROR - 2024-10-24 19:36:19 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 22
ERROR - 2024-10-24 19:36:19 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 22
ERROR - 2024-10-24 19:36:19 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 26
ERROR - 2024-10-24 19:36:19 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 26
ERROR - 2024-10-24 19:36:19 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 30
ERROR - 2024-10-24 19:36:19 --> Severity: Warning --> Attempt to read property "link" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 30
ERROR - 2024-10-24 19:36:23 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 22
ERROR - 2024-10-24 19:36:23 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 22
ERROR - 2024-10-24 19:36:23 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 26
ERROR - 2024-10-24 19:36:23 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 26
ERROR - 2024-10-24 19:36:23 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 30
ERROR - 2024-10-24 19:36:23 --> Severity: Warning --> Attempt to read property "link" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 30
ERROR - 2024-10-24 19:40:06 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 22
ERROR - 2024-10-24 19:40:06 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 22
ERROR - 2024-10-24 19:40:06 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 26
ERROR - 2024-10-24 19:40:06 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 26
ERROR - 2024-10-24 19:40:06 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 30
ERROR - 2024-10-24 19:40:06 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 30
ERROR - 2024-10-24 19:40:06 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 34
ERROR - 2024-10-24 19:40:06 --> Severity: Warning --> Attempt to read property "link" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 34
ERROR - 2024-10-24 19:40:08 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 22
ERROR - 2024-10-24 19:40:08 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 22
ERROR - 2024-10-24 19:40:08 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 26
ERROR - 2024-10-24 19:40:08 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 26
ERROR - 2024-10-24 19:40:08 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 30
ERROR - 2024-10-24 19:40:08 --> Severity: Warning --> Attempt to read property "title" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 30
ERROR - 2024-10-24 19:40:08 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 34
ERROR - 2024-10-24 19:40:08 --> Severity: Warning --> Attempt to read property "link" on null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 34
ERROR - 2024-10-24 19:45:58 --> Severity: error --> Exception: Call to undefined function csrf_field() C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 40
ERROR - 2024-10-24 20:04:57 --> Severity: Warning --> Attempt to read property "id" on array C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 25
ERROR - 2024-10-24 20:05:11 --> Severity: Warning --> Attempt to read property "id" on array C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 25
ERROR - 2024-10-24 20:09:52 --> Severity: error --> Exception: syntax error, unexpected variable "$this", expecting "function" or "const" C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 65
ERROR - 2024-10-24 20:10:24 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 121
ERROR - 2024-10-24 20:11:09 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:02 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:07 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:10 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:10 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:10 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:11 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:11 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:11 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:11 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:11 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:13 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:13 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:13 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:14:13 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: SELECT *
FROM `navbar`
WHERE `id` = '1'
ERROR - 2024-10-24 20:28:43 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-24 20:30:58 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-24 20:31:17 --> 404 Page Not Found: Admin/site_settings

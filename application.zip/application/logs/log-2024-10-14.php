<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-14 06:41:19 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-14 06:41:37 --> 404 Page Not Found: About/index
ERROR - 2024-10-14 06:42:40 --> 404 Page Not Found: Admin/about
ERROR - 2024-10-14 07:05:38 --> 404 Page Not Found: Admin/about
ERROR - 2024-10-14 07:11:49 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 13
ERROR - 2024-10-14 07:11:51 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 13
ERROR - 2024-10-14 07:17:12 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-14 07:21:59 --> Severity: error --> Exception: Unclosed '{' on line 4 C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 35
ERROR - 2024-10-14 07:22:32 --> Severity: error --> Exception: Unclosed '{' on line 4 C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 35
ERROR - 2024-10-14 07:22:33 --> Severity: error --> Exception: Unclosed '{' on line 4 C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 35
ERROR - 2024-10-14 07:23:10 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-14 07:23:21 --> 404 Page Not Found: About/index
ERROR - 2024-10-14 07:24:06 --> 404 Page Not Found: Admin/admin
ERROR - 2024-10-14 07:24:15 --> 404 Page Not Found: Admin/admin
ERROR - 2024-10-14 07:43:29 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-14 07:43:36 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-14 08:26:40 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-14 08:35:50 --> Severity: error --> Exception: syntax error, unexpected token "endforeach", expecting end of file C:\xampp\htdocs\portfolio\application\views\admin\about.php 94
ERROR - 2024-10-14 08:46:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:46:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:46:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:46:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:46:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:46:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:47:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:47:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:47:40 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:47:53 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:47:53 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:47:53 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:49:50 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:49:50 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:49:50 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:49:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:49:55 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 08:49:55 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 09:26:46 --> Severity: Warning --> Undefined variable $about_entries C:\xampp\htdocs\portfolio\application\views\admin\about.php 18
ERROR - 2024-10-14 09:26:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\about.php 18
ERROR - 2024-10-14 10:56:34 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 11:19:57 --> 404 Page Not Found: About/save
ERROR - 2024-10-14 11:21:17 --> 404 Page Not Found: About/save_about
ERROR - 2024-10-14 11:21:51 --> 404 Page Not Found: About/save_about
ERROR - 2024-10-14 12:11:57 --> 404 Page Not Found: About/save_about
ERROR - 2024-10-14 12:12:01 --> 404 Page Not Found: About/index
ERROR - 2024-10-14 12:34:35 --> 404 Page Not Found: About/save_about
ERROR - 2024-10-14 12:37:07 --> 404 Page Not Found: About/save_about
ERROR - 2024-10-14 12:39:11 --> 404 Page Not Found: SliderController/save_about
ERROR - 2024-10-14 12:39:21 --> 404 Page Not Found: SliderController/save_about
ERROR - 2024-10-14 13:07:47 --> 404 Page Not Found: AboutController/about
ERROR - 2024-10-14 13:07:49 --> 404 Page Not Found: AboutController/about
ERROR - 2024-10-14 13:08:07 --> 404 Page Not Found: AboutController/about
ERROR - 2024-10-14 13:08:10 --> 404 Page Not Found: AboutController/about
ERROR - 2024-10-14 13:10:35 --> 404 Page Not Found: AboutController/about
ERROR - 2024-10-14 13:10:48 --> 404 Page Not Found: AboutController/about
ERROR - 2024-10-14 13:10:50 --> 404 Page Not Found: AboutController/about
ERROR - 2024-10-14 13:43:14 --> 404 Page Not Found: Admin/about
ERROR - 2024-10-14 13:57:23 --> The upload path does not appear to be valid.
ERROR - 2024-10-14 13:57:23 --> The upload path does not appear to be valid.
ERROR - 2024-10-14 14:29:27 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 14:29:27 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 14:29:27 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 14:29:34 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 14:29:35 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 14:29:35 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-14 14:32:28 --> Severity: Warning --> Undefined array key "allowed_types" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 95
ERROR - 2024-10-14 14:33:47 --> Severity: Warning --> Undefined array key "allowed_types" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 95
ERROR - 2024-10-14 14:34:28 --> Severity: Warning --> Undefined array key "allowed_types" C:\xampp\htdocs\portfolio\application\controllers\AboutController.php 95

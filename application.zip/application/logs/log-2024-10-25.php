<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-25 08:08:07 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 08:08:10 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 08:08:33 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 08:08:35 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 08:08:36 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 08:09:32 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 08:11:52 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 08:11:53 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 08:37:06 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 37
ERROR - 2024-10-25 08:37:06 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 43
ERROR - 2024-10-25 08:37:13 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 37
ERROR - 2024-10-25 08:37:13 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 43
ERROR - 2024-10-25 08:37:17 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 37
ERROR - 2024-10-25 08:37:17 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 43
ERROR - 2024-10-25 08:37:26 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 37
ERROR - 2024-10-25 08:37:26 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 43
ERROR - 2024-10-25 08:37:30 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 37
ERROR - 2024-10-25 08:37:30 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 43
ERROR - 2024-10-25 08:37:54 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 37
ERROR - 2024-10-25 08:37:54 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 43
ERROR - 2024-10-25 08:40:35 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 34
ERROR - 2024-10-25 08:40:35 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 39
ERROR - 2024-10-25 08:41:40 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 34
ERROR - 2024-10-25 08:41:40 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 39
ERROR - 2024-10-25 08:45:32 --> Severity: Warning --> Undefined property: stdClass::$description C:\xampp\htdocs\portfolio\application\views\admin\manage_contacts.php 44
ERROR - 2024-10-25 08:51:09 --> 404 Page Not Found: Admin/update_contact
ERROR - 2024-10-25 08:52:37 --> 404 Page Not Found: Admin/save_contact
ERROR - 2024-10-25 08:55:03 --> 404 Page Not Found: Skill/save_contact
ERROR - 2024-10-25 09:07:58 --> Severity: Warning --> Undefined variable $about C:\xampp\htdocs\portfolio\application\views\admin\contact.php 64
ERROR - 2024-10-25 09:07:58 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\portfolio\application\views\admin\contact.php 64
ERROR - 2024-10-25 09:11:30 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:13:04 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:15:20 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:15:56 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:16:11 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:18:22 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:18:40 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:23:22 --> Severity: Warning --> Undefined variable $about C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:23:22 --> Severity: Warning --> Attempt to read property "image" on null C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:25:54 --> Severity: error --> Exception: syntax error, unexpected token "endif" C:\xampp\htdocs\portfolio\application\views\index.php 502
ERROR - 2024-10-25 09:26:32 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:26:32 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:26:32 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:26:32 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:27:07 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:27:07 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:27:07 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:27:07 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:27:30 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:27:30 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:27:30 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:27:30 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 495
ERROR - 2024-10-25 09:28:16 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:28:16 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:28:16 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:28:16 --> Severity: Warning --> Undefined property: stdClass::$image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:29:37 --> Severity: Warning --> Undefined variable $image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:29:37 --> Severity: Warning --> Undefined property: stdClass::$ C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:29:37 --> Severity: Warning --> Undefined variable $image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:29:37 --> Severity: Warning --> Undefined property: stdClass::$ C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:29:37 --> Severity: Warning --> Undefined variable $image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:29:37 --> Severity: Warning --> Undefined property: stdClass::$ C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:29:37 --> Severity: Warning --> Undefined variable $image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:29:37 --> Severity: Warning --> Undefined property: stdClass::$ C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:30:29 --> Severity: error --> Exception: syntax error, unexpected token "endforeach", expecting "elseif" or "else" or "endif" C:\xampp\htdocs\portfolio\application\views\index.php 500
ERROR - 2024-10-25 09:30:31 --> Severity: error --> Exception: syntax error, unexpected token "endforeach", expecting "elseif" or "else" or "endif" C:\xampp\htdocs\portfolio\application\views\index.php 500
ERROR - 2024-10-25 09:30:47 --> Severity: Warning --> Undefined variable $image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:30:47 --> Severity: Warning --> Undefined property: stdClass::$ C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:30:47 --> Severity: Warning --> Undefined variable $image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:30:47 --> Severity: Warning --> Undefined property: stdClass::$ C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:30:47 --> Severity: Warning --> Undefined variable $image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:30:47 --> Severity: Warning --> Undefined property: stdClass::$ C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:30:47 --> Severity: Warning --> Undefined variable $image C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:30:47 --> Severity: Warning --> Undefined property: stdClass::$ C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 09:31:13 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "assets/uploads/contacts/", expecting ")" C:\xampp\htdocs\portfolio\application\views\index.php 494
ERROR - 2024-10-25 10:47:43 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\portfolio\application\views\index.php 615
ERROR - 2024-10-25 10:47:52 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\portfolio\application\views\index.php 615
ERROR - 2024-10-25 10:56:12 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-25 10:57:38 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-25 10:57:48 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-25 11:03:31 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-25 11:03:42 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-25 11:03:45 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-25 11:09:11 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-25 11:09:23 --> 404 Page Not Found: SiteSettingsController/add
ERROR - 2024-10-25 11:18:47 --> 404 Page Not Found: SiteSettingsController/add
ERROR - 2024-10-25 11:19:06 --> 404 Page Not Found: SiteSettingsController/add
ERROR - 2024-10-25 11:19:09 --> 404 Page Not Found: SiteSettingsController/add
ERROR - 2024-10-25 11:19:18 --> 404 Page Not Found: SiteSettingsController/add
ERROR - 2024-10-25 11:22:57 --> 404 Page Not Found: SiteSettingsController/add
ERROR - 2024-10-25 11:28:48 --> Severity: error --> Exception: Call to undefined method Navbar_model::add_navbar_item() C:\xampp\htdocs\portfolio\application\controllers\SiteSettingsController.php 76
ERROR - 2024-10-25 11:32:16 --> 404 Page Not Found: Navbar/index
ERROR - 2024-10-25 11:32:17 --> 404 Page Not Found: Navbar/index
ERROR - 2024-10-25 11:32:34 --> Query error: Table 'portfolio.navbar' doesn't exist - Invalid query: INSERT INTO `navbar` (`title`, `link`) VALUES ('home', 'http://localhost/portfolio/admin/site-settings')
ERROR - 2024-10-25 11:33:12 --> 404 Page Not Found: Navbar/index
ERROR - 2024-10-25 11:37:56 --> 404 Page Not Found: Navbar/index
ERROR - 2024-10-25 11:45:20 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-25 11:45:35 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 12
ERROR - 2024-10-25 11:49:02 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 12
ERROR - 2024-10-25 11:53:09 --> Severity: Warning --> Undefined variable $nav C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 12
ERROR - 2024-10-25 11:54:13 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 12
ERROR - 2024-10-25 11:54:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\portfolio\application\views\admin\site_settings.php 12
ERROR - 2024-10-25 12:00:29 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-25 12:14:34 --> 404 Page Not Found: Admin/site_settings
ERROR - 2024-10-25 12:18:40 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:18:40 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:18:40 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:25:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:25:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:25:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:43:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:43:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:43:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:44:18 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:44:18 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:44:18 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:44:34 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:44:34 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:44:34 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:44:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:44:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:44:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:46:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:46:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:46:39 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:47:49 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 12:50:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:50:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 12:50:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:00:37 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:00:37 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:00:37 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:01:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:01:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:01:16 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:01:32 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:01:33 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:01:33 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:03:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:03:31 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:03:32 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:04:21 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:04:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:04:22 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:07:46 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:07:46 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:07:46 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:08:20 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:08:20 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:08:20 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:09:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:09:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:09:11 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:10:53 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:10:53 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:10:53 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:12:19 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:12:19 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:12:19 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:13:49 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:13:49 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:13:49 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:14:15 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:14:15 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:14:15 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:16:12 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:16:12 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:16:12 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:18:08 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:18:08 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:18:08 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:25:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:25:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:25:02 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-25 13:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 13:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 13:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-25 13:41:16 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-25 13:57:13 --> 404 Page Not Found: Icon-twitter/index
ERROR - 2024-10-25 14:01:21 --> 404 Page Not Found: Admin/update-footer
ERROR - 2024-10-25 14:01:29 --> 404 Page Not Found: Admin/update_footer
ERROR - 2024-10-25 14:02:20 --> 404 Page Not Found: Admin/update_footer
ERROR - 2024-10-25 14:05:39 --> 404 Page Not Found: Admin/update_footer
ERROR - 2024-10-25 14:05:50 --> 404 Page Not Found: Admin/site_settings

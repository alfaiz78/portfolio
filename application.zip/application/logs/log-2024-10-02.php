<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-02 09:21:35 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-02 09:21:35 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-02 09:21:36 --> 404 Page Not Found: Assets/admin

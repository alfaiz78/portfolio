<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-16 10:40:21 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-16 10:40:47 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-16 10:41:02 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-16 12:38:43 --> 404 Page Not Found: Resume/save_resume
ERROR - 2024-10-16 12:41:30 --> Severity: error --> Exception: Call to undefined method Slider_model::get_resumes() C:\xampp\htdocs\portfolio\application\controllers\ResumeController.php 63
ERROR - 2024-10-16 12:56:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 12:56:54 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 12:56:55 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:17:29 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-16 13:22:44 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-16 13:22:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-16 13:22:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-16 13:22:45 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-16 13:32:03 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-16 13:34:10 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:34:10 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:34:10 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:34:56 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-16 13:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-16 13:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-16 13:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-16 13:35:41 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:35:41 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:35:41 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:37:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:37:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:37:57 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:42:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:42:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:42:01 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:55:36 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:55:36 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:55:36 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:59:41 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:59:41 --> 404 Page Not Found: Assets/admin
ERROR - 2024-10-16 13:59:41 --> 404 Page Not Found: Assets/admin

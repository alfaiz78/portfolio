<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-19 11:49:17 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 11:49:17 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 11:50:13 --> Severity: Warning --> Undefined variable $hservices C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-19 11:50:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-19 12:04:48 --> Severity: Warning --> Undefined variable $hkills C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-19 12:04:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-19 12:05:19 --> Severity: Warning --> Undefined variable $hskills C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-19 12:05:19 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-19 12:06:12 --> Severity: Warning --> Undefined variable $hSkills C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-19 12:06:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-19 12:06:49 --> Severity: Warning --> Undefined variable $hskills C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-19 12:06:49 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\portfolio\application\views\admin\skill.php 23
ERROR - 2024-10-19 12:57:55 --> 404 Page Not Found: SkillController/manage_skill
ERROR - 2024-10-19 12:59:20 --> 404 Page Not Found: Admin/skill
ERROR - 2024-10-19 13:16:23 --> 404 Page Not Found: Admin/skill
ERROR - 2024-10-19 20:09:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:09:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:09:24 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-19 20:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-19 20:10:46 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:10:46 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:10:46 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:10:56 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-19 20:10:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:10:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:10:57 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:15:23 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\index.php 269
ERROR - 2024-10-19 20:15:23 --> Severity: Warning --> Undefined property: stdClass::$bg_title C:\xampp\htdocs\portfolio\application\views\index.php 269
ERROR - 2024-10-19 20:23:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:23:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:23:51 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:23:51 --> 404 Page Not Found: Assets/css
ERROR - 2024-10-19 20:28:56 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:29:00 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 20:47:05 --> 404 Page Not Found: Assets/js
ERROR - 2024-10-19 21:07:57 --> 404 Page Not Found: Index/index
ERROR - 2024-10-19 21:10:16 --> 404 Page Not Found: Admin/login.html
